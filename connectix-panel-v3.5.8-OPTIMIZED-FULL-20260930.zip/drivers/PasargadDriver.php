<?php
require_once __DIR__ . '/PanelDriverInterface.php';
require_once __DIR__ . '/../core/Helpers.php';

class PasargadDriver implements PanelDriverInterface {
    private string $baseUrl;
    private ?string $username;
    private ?string $password;
    private ?string $token;
    private ?string $subDomain = null;
    private string $apiPrefix = '/api';
    private bool $isPasarGuard = true; // Modern PasarGuard (FastAPI) vs legacy Pasargad
    private ?string $lastError = null;
    private int $timeout = 12;

    public function __construct(string $baseUrl, ?string $username = null, ?string $password = null, ?string $token = null, ?string $subDomain = null) {
        $clean = rtrim(trim($baseUrl), '/');
        $clean = preg_replace('#/(dashboard|admin|api|v1)+/?$#i', '', $clean);
        $this->baseUrl = rtrim($clean, '/');

        $this->username = $username ? trim($username) : null;
        $this->password = $password ? trim($password) : null;
        $this->token = $token ? trim($token) : ($this->username ? null : $this->password);
        $this->subDomain = $subDomain ? trim($subDomain) : null;
    }

    public function getLastError(): ?string {
        return $this->lastError;
    }

    public static function formatExpireDate(mixed $raw): ?string {
        if (empty($raw)) return null;
        if (is_numeric($raw)) {
            $ts = (int)$raw;
            if ($ts > 20000000000) $ts = (int)round($ts / 1000);
            return ($ts > 0) ? date('Y-m-d H:i:s', $ts) : null;
        }
        if (is_string($raw)) {
            $ts = strtotime($raw);
            return ($ts !== false && $ts > 0) ? date('Y-m-d H:i:s', $ts) : $raw;
        }
        return null;
    }

    private function getEffectiveSubDomain(): string {
        if (!empty($this->subDomain)) {
            $clean = trim($this->subDomain);
            return str_starts_with($clean, 'http') ? rtrim($clean, '/') : ('https://' . rtrim($clean, '/'));
        }
        return $this->baseUrl;
    }

    public function applySubDomain(string $url): string {
        if (empty($url)) return $url;
        $parts = parse_url($url);
        if (!$parts) return $url;

        // Target domain to rewrite to
        $targetDomain = !empty($this->subDomain) ? trim($this->subDomain) : '';
        if (empty($targetDomain) || str_contains($targetDomain, 'montago-shop.ir')) {
            $targetDomain = $this->getEffectiveSubDomain();
        }

        $scheme = str_starts_with($targetDomain, 'http://') ? 'http' : 'https';
        $targetHost = preg_replace('#^https?://#i', '', rtrim($targetDomain, '/'));

        $path = $parts['path'] ?? '';
        $query = !empty($parts['query']) ? ('?' . $parts['query']) : '';
        $fragment = !empty($parts['fragment']) ? ('#' . $parts['fragment']) : '';

        return "{$scheme}://{$targetHost}{$path}{$query}{$fragment}";
    }

    public function request(string $endpoint, string $method = 'GET', ?array $data = null, bool $isForm = false): array {
        $ch = curl_init();
        $url = $this->baseUrl . $endpoint;

        $headers = [
            'Accept: application/json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ];

        if (!empty($this->token)) {
            $headers[] = 'Authorization: Bearer ' . $this->token;
            $headers[] = 'X-API-KEY: ' . $this->token;
        }

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($isForm) {
                $headers[] = 'Content-Type: application/x-www-form-urlencoded';
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data ?? []));
            } else {
                $headers[] = 'Content-Type: application/json';
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data ?? []));
            }
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data ?? []));
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            $this->lastError = "خطای اتصال به سرور پاسارگاد (cURL): {$err}";
            return ['success' => false, 'code' => $httpCode, 'error' => $err, 'data' => null];
        }

        $decoded = json_decode((string)$response, true);
        $isSuccess = ($httpCode >= 200 && $httpCode < 300);

        if (!$isSuccess) {
            $detail = $decoded['detail'] ?? $decoded['message'] ?? null;
            if ($detail) {
                if (is_array($detail)) {
                    $detail = json_encode($detail, JSON_UNESCAPED_UNICODE);
                }
                if (stripos($detail, 'Incorrect') !== false || stripos($detail, 'password') !== false) {
                    $this->lastError = "نام کاربری یا رمز عبور ادمین پاسارگاد اشتباه است.";
                } else {
                    $this->lastError = "پاسخ سرور پاسارگاد: {$detail} (کد {$httpCode})";
                }
            } elseif ($httpCode === 403) {
                $this->lastError = "دسترسی توسط فایروال یا کلودفلر سرور پاسارگاد مسدود شد (خطای ۴۰۳ Cloudflare/WAF).";
            } elseif ($httpCode === 404) {
                $this->lastError = "مسیر وب‌سرویس پاسارگاد در این آدرس یافت نشد (کد ۴۰۴).";
            } else {
                $this->lastError = "خطای سرور پاسارگاد با کد HTTP {$httpCode}";
            }
        }

        return [
            'success' => $isSuccess,
            'code' => $httpCode,
            'data' => $decoded,
            'raw' => $response
        ];
    }

    public function authenticate(): bool {
        // Strategy A: If token is already present, test with system status
        if (!empty($this->token)) {
            foreach (['/api/system', '/api/v1/system', '/api/status', '/api/inbounds'] as $testEndpoint) {
                $res = $this->request($testEndpoint);
                if ($res['success'] || $res['code'] === 200) {
                    $this->isPasarGuard = str_contains($testEndpoint, 'system') || str_contains($testEndpoint, 'inbounds');
                    $this->apiPrefix = str_starts_with($testEndpoint, '/api/v1') ? '/api/v1' : '/api';
                    $this->lastError = null;
                    return true;
                }
            }
        }

        // Strategy B: Modern PasarGuard with username & password (OAuth2 Form /api/admin/token)
        if (!empty($this->username) && !empty($this->password)) {
            // 1. Try form-urlencoded login endpoints
            foreach (['/api/admin/token', '/api/v1/admin/token', '/api/admin/login'] as $endpoint) {
                $res = $this->request($endpoint, 'POST', [
                    'username' => $this->username,
                    'password' => $this->password
                ], true);

                if ($res['success'] && !empty($res['data']['access_token'])) {
                    $this->token = $res['data']['access_token'];
                    $this->isPasarGuard = true;
                    $this->apiPrefix = str_starts_with($endpoint, '/api/v1') ? '/api/v1' : '/api';
                    $this->lastError = null;
                    return true;
                }
            }

            // 2. Try JSON body login endpoints (FastAPI / Pasargad JSON APIs)
            foreach (['/api/admin/token', '/api/v1/admin/token', '/api/admin/login', '/api/v1/auth/login', '/api/auth/token'] as $endpoint) {
                $res = $this->request($endpoint, 'POST', [
                    'username' => $this->username,
                    'password' => $this->password
                ], false);

                $tokenCandidate = $res['data']['access_token'] ?? $res['data']['token'] ?? null;
                if ($res['success'] && !empty($tokenCandidate)) {
                    $this->token = $tokenCandidate;
                    $this->isPasarGuard = true;
                    $this->apiPrefix = str_starts_with($endpoint, '/api/v1') ? '/api/v1' : '/api';
                    $this->lastError = null;
                    return true;
                }
            }
        }

        // Strategy C: Legacy Pasargad token authentication via /api/status
        $candidateToken = $this->token ?: $this->password;
        if (!empty($candidateToken)) {
            $this->token = $candidateToken;
            $res = $this->request('/api/status');
            if ($res['success'] || $res['code'] === 200) {
                $this->isPasarGuard = false;
                $this->lastError = null;
                return true;
            }
        }

        if (empty($this->username) && empty($this->token)) {
            $this->lastError = "نام کاربری و کلمه عبور یا توکن API وارد نشده است.";
        }

        return false;
    }

    public function getDetailedInbounds(): array {
        if (!$this->authenticate()) return [];
        $res = $this->request($this->apiPrefix . '/inbounds');
        if ($res['success'] && is_array($res['data'])) {
            $list = [];
            if (isset($res['data'][0]) && is_array($res['data'][0])) {
                foreach ($res['data'] as $item) {
                    if (is_array($item)) {
                        $list[] = [
                            'tag' => $item['tag'] ?? 'Inbound',
                            'protocol' => strtolower($item['protocol'] ?? 'vless'),
                            'network' => $item['network'] ?? 'tcp',
                            'tls' => $item['tls'] ?? 'none',
                            'port' => $item['port'] ?? 443
                        ];
                    }
                }
            } else {
                foreach ($res['data'] as $proto => $items) {
                    if (is_array($items)) {
                        foreach ($items as $item) {
                            if (is_array($item)) {
                                $list[] = [
                                    'tag' => $item['tag'] ?? 'Inbound',
                                    'protocol' => strtolower((string)$proto),
                                    'network' => $item['network'] ?? 'tcp',
                                    'tls' => $item['tls'] ?? 'none',
                                    'port' => $item['port'] ?? 443
                                ];
                            }
                        }
                    }
                }
            }
            return $list;
        }
        return [];
    }

    public function getInbounds(): array {
        if (!$this->authenticate()) return [];
        $res = $this->request($this->apiPrefix . '/inbounds');
        if ($res['success'] && is_array($res['data'])) {
            $inbounds = [];
            // Check if flat list
            if (isset($res['data'][0]) && is_array($res['data'][0])) {
                foreach ($res['data'] as $item) {
                    if (is_array($item)) {
                        $proto = strtolower($item['protocol'] ?? 'vless');
                        $tag = $item['tag'] ?? null;
                        if ($tag) {
                            $inbounds[$proto][] = $tag;
                        }
                    }
                }
            } else {
                foreach ($res['data'] as $proto => $items) {
                    $protoLower = strtolower((string)$proto);
                    if (is_array($items)) {
                        $inbounds[$protoLower] = [];
                        foreach ($items as $item) {
                            if (is_array($item) && !empty($item['tag'])) {
                                $inbounds[$protoLower][] = $item['tag'];
                            } elseif (is_string($item)) {
                                $inbounds[$protoLower][] = $item;
                            }
                        }
                    }
                }
            }
            return $inbounds;
        }
        return [];
    }

    public function createUser(array $payload): array {
        if (!$this->authenticate()) {
            return [
                'success' => false,
                'error' => $this->lastError ?: 'عدم موفقیت در احراز هویت با پنل پاسارگاد',
                'uuid' => '',
                'sublink' => ''
            ];
        }

        $domainBase = $this->getEffectiveSubDomain();

        if ($this->isPasarGuard) {
            // Modern PasarGuard
            $allInbounds = $this->getInbounds();
            $inbounds = $allInbounds;

            if (!empty($payload['selected_inbounds'])) {
                $selectedTags = is_array($payload['selected_inbounds']) 
                    ? $payload['selected_inbounds'] 
                    : json_decode($payload['selected_inbounds'], true);

                if (!empty($selectedTags) && is_array($selectedTags)) {
                    $filtered = [];
                    foreach ($allInbounds as $proto => $tags) {
                        foreach ($tags as $t) {
                            if (in_array($t, $selectedTags)) {
                                $filtered[$proto][] = $t;
                            }
                        }
                    }
                    if (!empty($filtered)) {
                        $inbounds = $filtered;
                    }
                }
            }

            $hasReality = false;
            $detailed = $this->getDetailedInbounds();
            foreach ($detailed as $d) {
                if ($d['protocol'] === 'vless' && ($d['tls'] === 'reality' || str_contains(strtolower($d['tag']), 'reality'))) {
                    $hasReality = true;
                    break;
                }
            }

            $proxies = [
                'vless' => ['id' => $payload['uuid'], 'flow' => $hasReality ? 'xtls-rprx-vision' : ''],
                'vmess' => ['id' => $payload['uuid']],
                'trojan' => ['password' => $payload['password'] ?? $payload['uuid']],
                'shadowsocks' => ['password' => $payload['password'] ?? $payload['uuid'], 'method' => 'chacha20-ietf-poly1305']
            ];

            if (!empty($inbounds)) {
                $filteredProxies = [];
                foreach ($inbounds as $proto => $tags) {
                    $protoLower = strtolower($proto);
                    if (isset($proxies[$protoLower])) {
                        $filteredProxies[$protoLower] = $proxies[$protoLower];
                    }
                }
                if (!empty($filteredProxies)) {
                    $proxies = $filteredProxies;
                }
            }

            $body = [
                'username' => $payload['username'],
                'proxies' => $proxies,
                'expire' => $payload['expire_timestamp'] ?? null,
                'data_limit' => $payload['traffic_limit_bytes'] ?? 0,
                'data_limit_reset_strategy' => 'no_reset',
                'status' => 'active',
                'group_ids' => [1],
                'note' => 'Provisioned automatically via Connectix Panel'
            ];

            // Note: Omit sub_token so PasarGuard generates its own official cryptographic signed JWT token (e.g. djMsNTM5Njc4...)

            if (!empty($inbounds)) {
                $body['inbounds'] = $inbounds;
            }

            $res = $this->request($this->apiPrefix . '/user', 'POST', $body);
            if (!$res['success']) {
                $errRaw = is_array($res['data'] ?? '') ? json_encode($res['data'], JSON_UNESCAPED_UNICODE) : (string)($res['data'] ?? '');
                if ($res['code'] === 409 || stripos($errRaw, 'already') !== false || stripos($errRaw, 'exist') !== false || stripos($errRaw, 'موجود') !== false) {
                    $live = $this->getUser($payload['username']);
                    if ($live) {
                        return [
                            'success' => true,
                            'uuid' => $payload['uuid'],
                            'sublink' => $live['subscription_url'] ?? '',
                            'links' => $live['links'] ?? [],
                            'vless_link' => $live['links'][0] ?? '',
                            'error' => null
                        ];
                    }
                }
            }

            if ($res['success']) {
                $data = $res['data'] ?? [];

                // Fetch fresh user profile from node to ensure server core has resolved all links & sublink
                $live = $this->getUser($payload['username']);
                if ($live && !empty($live['subscription_url'])) {
                    $subUrl = $live['subscription_url'];
                    $links = $live['links'] ?? [];
                } else {
                    $subUrl = $data['subscription_url'] 
                           ?? $data['sub_link'] 
                           ?? $data['sub_url'] 
                           ?? $data['subscription_link'] 
                           ?? (!empty($data['sub_token']) ? ('/sub/' . $data['sub_token']) : '');
                    $links = $data['links'] ?? [];
                }

                if (empty($subUrl) && !empty($links)) {
                    $subUrl = $links[0];
                }

                if (!empty($subUrl) && str_starts_with($subUrl, '/')) {
                    $subUrl = $domainBase . $subUrl;
                } elseif (!empty($subUrl) && !empty($this->subDomain)) {
                    $subUrl = $this->applySubDomain($subUrl);
                }

                $primarySub = $subUrl ?: ($domainBase . '/sub/' . ($payload['sub_token'] ?? $payload['uuid']));

                return [
                    'success' => true,
                    'uuid' => $payload['uuid'],
                    'sublink' => $primarySub,
                    'links' => $links,
                    'vless_link' => $links[0] ?? '',
                    'error' => null
                ];
            }

            $errMsg = $res['data']['detail'] ?? $this->lastError ?? 'خطا در ایجاد کاربر پاسارگاد';
            return [
                'success' => false,
                'error' => is_array($errMsg) ? json_encode($errMsg, JSON_UNESCAPED_UNICODE) : $errMsg,
                'uuid' => '',
                'sublink' => ''
            ];
        } else {
            // Legacy Pasargad
            $body = [
                'username' => $payload['username'],
                'uuid' => $payload['uuid'],
                'traffic_limit' => $payload['traffic_limit_bytes'] ?? 0,
                'expire_time' => $payload['expire_timestamp'] ?? 0,
                'status' => 'active'
            ];

            $res = $this->request('/api/users/add', 'POST', $body);
            if ($res['success']) {
                $raw = $res['data'] ?? [];
                $nested = $raw['data'] ?? [];
                $sublink = $raw['sub_link'] 
                        ?? $raw['subscription_url'] 
                        ?? $raw['sub_url'] 
                        ?? $nested['sub_link'] 
                        ?? $nested['subscription_url'] 
                        ?? '';

                if (empty($sublink)) {
                    $sublink = $domainBase . '/sub/' . ($payload['sub_token'] ?? $payload['uuid']);
                } elseif (str_starts_with($sublink, '/')) {
                    $sublink = $domainBase . $sublink;
                } else {
                    $sublink = $this->applySubDomain($sublink);
                }

                $links = !empty($raw['links']) ? $raw['links'] : (!empty($nested['links']) ? $nested['links'] : []);

                return [
                    'success' => true,
                    'uuid' => $payload['uuid'],
                    'sublink' => $sublink,
                    'links' => $links,
                    'vless_link' => $links[0] ?? ($raw['vless_link'] ?? ($nested['vless_link'] ?? '')),
                    'error' => null
                ];
            }

            return [
                'success' => false,
                'error' => $res['data']['message'] ?? $res['error'] ?? 'خطا در ثبت کلاینت در پنل پاسارگاد',
                'uuid' => '',
                'sublink' => ''
            ];
        }
    }

    public function getUser(string $username): ?array {
        if (!$this->authenticate()) return null;

        $domainBase = $this->getEffectiveSubDomain();

        if ($this->isPasarGuard) {
            $res = $this->request($this->apiPrefix . '/user/' . urlencode($username));
            if ($res['success'] && !empty($res['data'])) {
                $u = $res['data'];
                $subUrl = $u['subscription_url'] 
                       ?? $u['sub_link'] 
                       ?? $u['sub_url'] 
                       ?? (!empty($u['sub_token']) ? ('/sub/' . $u['sub_token']) : '');

                if (!empty($subUrl) && str_starts_with($subUrl, '/')) {
                    $subUrl = $domainBase . $subUrl;
                } elseif (!empty($subUrl)) {
                    $subUrl = $this->applySubDomain($subUrl);
                }

                // Auto-heal: Ensure user has group_ids [1] so inbounds/configs are active
                if (empty($u['group_ids'])) {
                    $this->request($this->apiPrefix . '/user/' . urlencode($username), 'PUT', ['group_ids' => [1]]);
                    $u['group_ids'] = [1];
                }

                $expireVal = self::formatExpireDate($u['expire'] ?? null);

                $links = $u['links'] ?? [];

                // If user links are empty in PasarGuard API response, fetch configs from the subscription URL directly!
                if (empty($links) && !empty($subUrl) && !Helpers::isPanelSubUrl($subUrl)) {
                    $ch = curl_init($subUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($ch, CURLOPT_USERAGENT, 'v2rayNG/1.8.5');
                    $subContent = curl_exec($ch);
                    curl_close($ch);
                    if (!empty($subContent)) {
                        $decoded = base64_decode(trim($subContent), true) ?: $subContent;
                        $lines = preg_split("/\r\n|\n|\r/", $decoded);
                        foreach ($lines as $l) {
                            $l = trim($l);
                            if (preg_match('/^(vless|vmess|trojan|ss|shadowsocks|hysteria2|hy2|tuic|wireguard):\/\//i', $l)) {
                                $links[] = $l;
                            }
                        }
                    }
                }

                return [
                    'traffic_used_bytes' => $u['used_traffic'] ?? $u['traffic_used'] ?? 0,
                    'traffic_limit_bytes' => $u['data_limit'] ?? $u['total_traffic'] ?? 0,
                    'expire_at' => $expireVal,
                    'status' => $u['status'] ?? 'active',
                    'online' => ($u['online_at'] ?? 0) > (time() - 300),
                    'links' => $links,
                    'subscription_url' => $subUrl
                ];
            }
        } else {
            $res = $this->request('/api/users/' . urlencode($username));
            if ($res['success'] && !empty($res['data'])) {
                $u = $res['data'];
                $subUrl = $u['sub_link'] ?? $u['subscription_url'] ?? '';

                if (!empty($subUrl) && str_starts_with($subUrl, '/')) {
                    $subUrl = $domainBase . $subUrl;
                } elseif (!empty($subUrl) && !empty($this->subDomain)) {
                    $subUrl = $this->applySubDomain($subUrl);
                }

                $expireVal = self::formatExpireDate($u['expire_time'] ?? null);

                $links = $u['links'] ?? [];

                if (empty($links) && !empty($subUrl) && !Helpers::isPanelSubUrl($subUrl)) {
                    $ch = curl_init($subUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($ch, CURLOPT_USERAGENT, 'v2rayNG/1.8.5');
                    $subContent = curl_exec($ch);
                    curl_close($ch);
                    if (!empty($subContent)) {
                        $decoded = base64_decode(trim($subContent), true) ?: $subContent;
                        $lines = preg_split("/\r\n|\n|\r/", $decoded);
                        foreach ($lines as $l) {
                            $l = trim($l);
                            if (preg_match('/^(vless|vmess|trojan|ss|shadowsocks|hysteria2|hy2|tuic|wireguard):\/\//i', $l)) {
                                $links[] = $l;
                            }
                        }
                    }
                }

                return [
                    'traffic_used_bytes' => $u['used_traffic'] ?? 0,
                    'traffic_limit_bytes' => $u['total_traffic'] ?? 0,
                    'expire_at' => $expireVal,
                    'status' => $u['status'] ?? 'active',
                    'online' => !empty($u['is_online']),
                    'links' => $links,
                    'subscription_url' => $subUrl
                ];
            }
        }
        return null;
    }

    public function extendUser(string $username, int $addTrafficBytes, int $addSeconds): bool {
        if (!$this->authenticate()) return false;

        if ($this->isPasarGuard) {
            $current = $this->getUser($username);
            if (!$current) return false;
            $newLimit = $current['traffic_limit_bytes'] + $addTrafficBytes;
            $currentExpire = !empty($current['expire_at']) ? strtotime($current['expire_at']) : time();
            $newExpire = max($currentExpire, time()) + $addSeconds;

            $res = $this->request($this->apiPrefix . '/user/' . urlencode($username), 'PUT', [
                'data_limit' => $newLimit,
                'expire' => $newExpire,
                'status' => 'active'
            ]);
            return $res['success'];
        } else {
            $res = $this->request('/api/users/' . urlencode($username) . '/extend', 'POST', [
                'add_traffic' => $addTrafficBytes,
                'add_seconds' => $addSeconds
            ]);
            return $res['success'];
        }
    }

    public function updateUser(string $username, array $params): bool {
        if (!$this->authenticate()) return false;
        $data = [];
        if (isset($params['traffic_limit_bytes'])) {
            $data['data_limit'] = (int)$params['traffic_limit_bytes'];
        }
        if (isset($params['expire_timestamp'])) {
            $data['expire'] = (int)$params['expire_timestamp'] > 0 ? (int)$params['expire_timestamp'] : null;
        }
        if (isset($params['status'])) {
            $data['status'] = $params['status'];
        }
        if ($this->isPasarGuard) {
            $res = $this->request($this->apiPrefix . '/user/' . urlencode($username), 'PUT', $data);
            return $res['success'];
        } else {
            $res = $this->request('/api/users/' . urlencode($username), 'PUT', $data);
            return $res['success'];
        }
    }

    public function deleteUser(string $username): bool {
        if (!$this->authenticate()) return false;
        $endpoint = $this->isPasarGuard ? ($this->apiPrefix . '/user/' . urlencode($username)) : ('/api/users/' . urlencode($username));
        $res = $this->request($endpoint, 'DELETE');
        return $res['success'];
    }

    public function toggleUserStatus(string $username, bool $active): bool {
        if (!$this->authenticate()) return false;
        if ($this->isPasarGuard) {
            $res = $this->request($this->apiPrefix . '/user/' . urlencode($username), 'PUT', [
                'status' => $active ? 'active' : 'disabled'
            ]);
            return $res['success'];
        } else {
            $res = $this->request('/api/users/' . urlencode($username) . '/status', 'PUT', [
                'active' => $active
            ]);
            return $res['success'];
        }
    }

    public function getNodeStats(): array {
        if (!$this->authenticate()) {
            return ['status' => 'offline', 'version' => 'Pasargad (عدم اتصال)', 'users' => 0];
        }

        if ($this->isPasarGuard) {
            $res = $this->request($this->apiPrefix . '/system');
            if ($res['success'] && !empty($res['data'])) {
                return [
                    'status' => 'online',
                    'version' => $res['data']['version'] ?? 'PasarGuard Core',
                    'users' => $res['data']['total_user'] ?? 0,
                    'cpu' => ($res['data']['cpu_usage'] ?? 0) . '%',
                    'ram' => round(($res['data']['mem_used'] ?? 0) / 1024 / 1024 / 1024, 1) . ' GB'
                ];
            }
        } else {
            $res = $this->request('/api/server/stats');
            if ($res['success'] && !empty($res['data'])) {
                return [
                    'status' => 'online',
                    'version' => 'Pasargad Panel',
                    'users' => $res['data']['active_users'] ?? 0,
                    'cpu' => ($res['data']['cpu'] ?? 0) . '%',
                    'ram' => ($res['data']['ram'] ?? 0) . '%'
                ];
            }
        }

        return ['status' => 'online', 'version' => 'Pasargad Core', 'users' => 0];
    }

    /**
     * List ALL users on this node (PasarGuard = Marzban-style API, legacy Pasargad = /api/users).
     */
    public function listUsers(): array {
        if (!$this->authenticate()) return [];

        $candidates = [];
        if ($this->isPasarGuard) {
            if ($this->apiPrefix === '/api/v1') {
                $candidates[] = $this->apiPrefix . '/client/list';
            } else {
                $candidates[] = $this->apiPrefix . '/v1/client/list';
                $candidates[] = $this->apiPrefix . '/client/list';
            }
        }
        $candidates[] = '/api/users';
        $candidates[] = $this->apiPrefix . '/users';

        $rawUsers = null;
        foreach ($candidates as $endpoint) {
            $res = $this->request($endpoint);
            if (!$res['success']) continue;
            $d = $res['data'];
            if (is_array($d) && isset($d['users']) && is_array($d['users'])) {
                $rawUsers = $d['users'];
            } elseif (is_array($d) && isset($d['data']) && is_array($d['data'])) {
                $rawUsers = $d['data'];
            } elseif (is_array($d) && isset($d[0])) {
                $rawUsers = $d;
            }
            if ($rawUsers !== null) break;
        }
        if ($rawUsers === null) return [];

        $out = [];
        foreach ($rawUsers as $u) {
            if (!is_array($u)) continue;
            $username = (string)($u['username'] ?? $u['name'] ?? '');
            if ($username === '') continue;

            $expRaw = $u['expire'] ?? $u['expired_at'] ?? $u['expire_at'] ?? null;
            $expAt = null;
            if (!empty($expRaw)) {
                if (is_numeric($expRaw)) {
                    $expAt = ((int)$expRaw > 0) ? date('Y-m-d H:i:s', (int)$expRaw) : null;
                } else {
                    $ts = strtotime((string)$expRaw);
                    $expAt = ($ts !== false && $ts > 0) ? date('Y-m-d H:i:s', $ts) : (string)$expRaw;
                }
            }

            $subUrl = (string)($u['subscription_url'] ?? $u['sub_url'] ?? '');
            if (!empty($subUrl) && str_starts_with($subUrl, '/')) {
                $domainBase = !empty($this->subDomain)
                    ? (str_starts_with($this->subDomain, 'http') ? rtrim($this->subDomain, '/') : ('https://' . rtrim($this->subDomain, '/')))
                    : $this->baseUrl;
                $subUrl = $domainBase . $subUrl;
            } else {
                $subUrl = $this->applySubDomain($subUrl);
            }

            $status = (string)($u['status'] ?? 'active');
            if ($expAt !== null && is_string($expAt) && strtotime($expAt) < time()) $status = 'expired';

            $links = (array)($u['links'] ?? []);

            $rawLimit = $u['data_limit'] ?? $u['traffic_limit'] ?? $u['total_traffic'] ?? $u['package_size'] ?? 0;
            $limitBytes = (int)$rawLimit;
            if ($limitBytes > 0 && $limitBytes < 10000) {
                // Specified in GB, convert to bytes
                $limitBytes = (int)round($limitBytes * 1073741824);
            }

            $rawUsed = $u['used_traffic'] ?? $u['used_bytes'] ?? $u['traffic_used'] ?? $u['used'] ?? 0;
            $usedBytes = (int)$rawUsed;
            if ($usedBytes > 0 && $usedBytes < 10000 && $limitBytes > 10000000) {
                // If used was reported in GB
                $usedBytes = (int)round($usedBytes * 1073741824);
            }

            $out[] = [
                'username' => $username,
                'status' => $status,
                'online' => ((int)($u['online_at'] ?? $u['last_login'] ?? 0)) > (time() - 300),
                'traffic_used_bytes' => $usedBytes,
                'traffic_limit_bytes' => $limitBytes,
                'expire_at' => $expAt,
                'subscription_url' => $subUrl,
                'links' => array_values(array_filter(array_map('strval', $links))),
            ];
        }
        return $out;
    }
}
