<?php
require __DIR__ . '/../layout/header.php';
?>

<!-- Header with Filters & Actions -->
<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-2xl shadow-sm">
    <div>
        <h2 class="text-lg font-bold text-white flex items-center gap-2">
            <i class="fa-solid fa-users text-cyan-400"></i>
            <span>مدیریت کلاینت‌ها و مشترکین</span>
        </h2>
        <p class="text-xs text-slate-400 mt-1">مشاهده، تمدید، رزرو پلن، خروجی ساب‌لینک، کد QR و عملیات گروهی</p>
    </div>

    <div class="flex items-center gap-2">
        <a href="<?= Helpers::url('clients/restore-traffic') ?>" onclick="return confirm('آیا مایلید ترافیک مصرفی واقعی کلاینت‌ها از اسنپ‌شات پایدار بازیابی شود؟');" class="px-3.5 py-2.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5" title="بازیابی ترافیک مصرفی واقعی از فایل پشتیبان پایدار">
            <i class="fa-solid fa-chart-pie text-cyan-400"></i>
            <span>بازیابی مصرف واقعی</span>
        </a>

        <a href="<?= Helpers::url('servers/sync') ?>" class="px-3.5 py-2.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5" title="بازخوانی و همگام‌سازی لحظه‌ای تمامی کلاینت‌ها از روی سرورها">
            <i class="fa-solid fa-cloud-arrow-down text-purple-400"></i>
            <span>بازخوانی از سرورها</span>
        </a>

        <button type="button" onclick="openOptimizerModal()" class="px-3.5 py-2.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5" title="پاکسازی و بهینه‌سازی سرویس‌های منقضی و بدون استفاده">
            <i class="fa-solid fa-broom text-rose-400"></i>
            <span>بهینه‌سازی و پاکسازی</span>
            <?php 
                $pendingClean = ($optimizerStats['unused'] ?? 0) + ($optimizerStats['expired_7d'] ?? 0);
                if ($pendingClean > 0): 
            ?>
                <span class="inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] bg-rose-600 text-white font-mono rounded-full font-bold shadow-sm"><?= $pendingClean ?></span>
            <?php endif; ?>
        </button>

        <button type="button" onclick="openTestModal()" class="px-3.5 py-2.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5" title="صدور آنی اکانت تست با حجم دلخواه (مثلاً ۲۰۰ یا ۵۰۰ مگابایت)">
            <i class="fa-solid fa-wand-magic-sparkles"></i>
            <span>صدور اکانت تست سریع</span>
        </button>

        <a href="<?= Helpers::url('clients/export') ?>?<?= http_build_query($_GET) ?>" class="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl border border-slate-700 transition flex items-center gap-2" title="دانلود خروجی اکسل و CSV از نتایج فیلترشده">
            <i class="fa-solid fa-file-excel text-emerald-400"></i>
            <span>خروجی اکسل</span>
        </a>

        <a href="<?= Helpers::url('clients/bulk') ?>" class="px-3.5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2" title="تولید همزمان ۱۰ الی ۱۰۰ اکانت اشتراک">
            <i class="fa-solid fa-layer-group"></i>
            <span>ساخت گروهی</span>
        </a>

        <a href="<?= Helpers::url('clients/create') ?>" class="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-purple-900/30 flex items-center gap-2">
            <i class="fa-solid fa-plus"></i>
            <span>ایجاد کاربر جدید</span>
        </a>
    </div>
</div>

<!-- Optimization Quick Filter Pills -->
<?php $currentFilter = $_GET['filter'] ?? $_GET['quick_filter'] ?? ''; ?>
<div class="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
    <span class="text-slate-400 font-semibold whitespace-nowrap text-[11px] flex items-center gap-1">
        <i class="fa-solid fa-bolt text-amber-400"></i> فیلترهای سریع:
    </span>
    <a href="<?= Helpers::url('clients') ?>" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= empty($currentFilter) ? 'bg-purple-600 text-white border-purple-500 font-bold' : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:bg-slate-800' ?>">
        <span>همه سرویس‌ها</span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=unused" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'unused' ? 'bg-amber-600 text-white border-amber-500 font-bold' : 'bg-slate-900/60 text-amber-300/80 border-slate-800 hover:bg-amber-950/40' ?>" title="سرویس‌هایی که حجم مصرفی آن‌ها صفر است">
        <i class="fa-solid fa-circle-pause text-[10px] text-amber-400"></i>
        <span>بدون مصرف (حجم صفر)</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-amber-500/20 text-amber-300 rounded font-mono font-bold"><?= $optimizerStats['unused'] ?? 0 ?></span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=expired_7d" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'expired_7d' ? 'bg-rose-600 text-white border-rose-500 font-bold' : 'bg-slate-900/60 text-rose-300/80 border-slate-800 hover:bg-rose-950/40' ?>" title="سرویس‌هایی که بیش از ۷ روز از تاریخ انقضای آن‌ها گذشته است">
        <i class="fa-solid fa-clock-rotate-left text-[10px] text-rose-400"></i>
        <span>منقضی > ۷ روز</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-rose-500/20 text-rose-300 rounded font-mono font-bold"><?= $optimizerStats['expired_7d'] ?? 0 ?></span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=expired_14d" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'expired_14d' ? 'bg-rose-700 text-white border-rose-600 font-bold' : 'bg-slate-900/60 text-rose-400/80 border-slate-800 hover:bg-rose-950/40' ?>" title="سرویس‌هایی که بیش از ۱۴ روز از تاریخ انقضای آن‌ها گذشته است">
        <i class="fa-solid fa-calendar-xmark text-[10px]"></i>
        <span>منقضی > ۱۴ روز</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-rose-500/20 text-rose-300 rounded font-mono font-bold"><?= $optimizerStats['expired_14d'] ?? 0 ?></span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=expired_30d" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'expired_30d' ? 'bg-rose-800 text-white border-rose-700 font-bold' : 'bg-slate-900/60 text-rose-400 border-slate-800 hover:bg-rose-950/40' ?>" title="سرویس‌هایی که بیش از ۱ ماه از تاریخ انقضای آن‌ها گذشته است">
        <i class="fa-solid fa-skull-crossbones text-[10px]"></i>
        <span>منقضی > ۳۰ روز</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-rose-500/20 text-rose-300 rounded font-mono font-bold"><?= $optimizerStats['expired_30d'] ?? 0 ?></span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=expired_all" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'expired_all' ? 'bg-red-700 text-white border-red-600 font-bold' : 'bg-slate-900/60 text-red-300/80 border-slate-800 hover:bg-red-950/40' ?>" title="تمامی سرویس‌های منقضی‌شده">
        <span>کل منقضی‌ها</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-red-500/20 text-red-300 rounded font-mono font-bold"><?= $optimizerStats['expired_all'] ?? 0 ?></span>
    </a>
    <a href="<?= Helpers::url('clients') ?>?filter=trials" class="px-3 py-1.5 rounded-lg border transition whitespace-nowrap flex items-center gap-1.5 <?= $currentFilter === 'trials' ? 'bg-cyan-700 text-white border-cyan-600 font-bold' : 'bg-slate-900/60 text-cyan-300 border-slate-800 hover:bg-cyan-950/40' ?>" title="اکانت‌های تست">
        <i class="fa-solid fa-vial text-[10px]"></i>
        <span>اکانت‌های تست</span>
        <span class="px-1.5 py-0.2 text-[10px] bg-cyan-500/20 text-cyan-300 rounded font-mono font-bold"><?= $optimizerStats['expired_trials'] ?? 0 ?></span>
    </a>
</div>

<!-- Search & Filter Form -->
<form method="GET" action="<?= Helpers::url('clients') ?>" class="bg-slate-900/50 p-4 rounded-xl border border-slate-800/80 text-xs space-y-3">
    <?php if (!empty($currentFilter)): ?>
        <input type="hidden" name="filter" value="<?= htmlspecialchars($currentFilter) ?>">
    <?php endif; ?>
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div>
            <label class="block text-slate-400 mb-1">جستجو:</label>
            <input type="text" name="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" placeholder="نام خریدار، کاربری، یادداشت..." 
                   class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
        </div>

        <div>
            <label class="block text-slate-400 mb-1">وضعیت اشتراک:</label>
            <select name="status" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                <option value="">همه وضعیت‌ها</option>
                <option value="active" <?= ($_GET['status'] ?? '') === 'active' ? 'selected' : '' ?>>فعال (Active)</option>
                <option value="waiting_connect" <?= ($_GET['status'] ?? '') === 'waiting_connect' ? 'selected' : '' ?>>در انتظار اولین اتصال</option>
                <option value="expired" <?= ($_GET['status'] ?? '') === 'expired' ? 'selected' : '' ?>>منقضی (Expired)</option>
                <option value="disabled" <?= ($_GET['status'] ?? '') === 'disabled' ? 'selected' : '' ?>>معلق (Disabled)</option>
                <option value="never_connected" <?= ($_GET['status'] ?? '') === 'never_connected' ? 'selected' : '' ?>>هرگز متصل نشده</option>
            </select>
        </div>

        <div>
            <label class="block text-slate-400 mb-1">کلاستر سرور:</label>
            <select name="group" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                <option value="">همه کلاسترها</option>
                <option value="default" <?= ($_GET['group'] ?? '') === 'default' ? 'selected' : '' ?>>عادی (Default)</option>
                <option value="economic" <?= ($_GET['group'] ?? '') === 'economic' ? 'selected' : '' ?>>اقتصادی (Economic)</option>
                <option value="iran_access" <?= ($_GET['group'] ?? '') === 'iran_access' ? 'selected' : '' ?>>ایران اکسس (Iran Access)</option>
                <option value="vip" <?= ($_GET['group'] ?? '') === 'vip' ? 'selected' : '' ?>>تجاری (VIP Business)</option>
            </select>
        </div>

        <div>
            <label class="block text-slate-400 mb-1">پلن تعرفه:</label>
            <select name="plan_id" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                <option value="">همه پلن‌ها</option>
                <?php foreach ($plans as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= (int)($_GET['plan_id'] ?? 0) === $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['title']) ?> (<?= $p['traffic_gb'] ?>GB)</option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label class="block text-slate-400 mb-1">فیلتر انقضا:</label>
            <select name="expire_filter" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                <option value="">همه تاریخ‌ها</option>
                <option value="expiring_soon" <?= ($_GET['expire_filter'] ?? '') === 'expiring_soon' ? 'selected' : '' ?>>کمتر از ۳ روز مانده</option>
                <option value="expired" <?= ($_GET['expire_filter'] ?? '') === 'expired' ? 'selected' : '' ?>>منقضی شده</option>
                <option value="unlimited" <?= ($_GET['expire_filter'] ?? '') === 'unlimited' ? 'selected' : '' ?>>بدون تاریخ انقضا</option>
            </select>
        </div>

        <div>
            <label class="block text-slate-400 mb-1">میزان مصرف حجم:</label>
            <select name="usage_filter" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                <option value="">همه مقادیر مصرف</option>
                <option value="critical" <?= ($_GET['usage_filter'] ?? '') === 'critical' ? 'selected' : '' ?>>بیش از ۹۰٪ (حجم بحرانی)</option>
                <option value="heavy" <?= ($_GET['usage_filter'] ?? '') === 'heavy' ? 'selected' : '' ?>>۵۰٪ الی ۹۰٪ مصرف</option>
                <option value="low" <?= ($_GET['usage_filter'] ?? '') === 'low' ? 'selected' : '' ?>>کمتر از ۲۰٪ مصرف</option>
            </select>
        </div>
    </div>

    <div class="flex items-center justify-between pt-2 border-t border-slate-800">
        <div class="text-[11px] text-slate-400">
            نمایش <b class="text-white"><?= count($clients) ?></b> کاربر با شرایط انتخاب‌شده
        </div>
        <div class="flex items-center gap-2">
            <button type="submit" class="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors font-medium flex items-center gap-1.5 shadow">
                <i class="fa-solid fa-filter text-xs"></i>
                <span>اعمال فیلترها</span>
            </button>
            <a href="<?= Helpers::url('clients') ?>" class="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg border border-slate-700 transition-colors flex items-center gap-1" title="پاکسازی همه فیلترها">
                <i class="fa-solid fa-rotate-right"></i>
                <span>حذف فیلترها</span>
            </a>
        </div>
    </div>
</form>

<!-- Clients Table with Bulk Operations Form -->
<form action="<?= Helpers::url('clients/bulk') ?>" method="POST" id="bulkForm">
    <?= Helpers::csrfField() ?>

    <!-- Bulk Action Toolbar -->
    <div class="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-xl border border-slate-800 text-xs">
        <div class="flex items-center gap-2 flex-wrap">
            <span class="text-slate-400 font-semibold">عملیات دسته‌جمعی:</span>
            <select name="bulk_action" required class="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-white">
                <option value="">-- انتخاب عملیات روی انتخاب‌شده‌ها --</option>
                <option value="extend_30_days">➕ تمدید ۳۰ روزه کلیه انتخاب‌شده‌ها</option>
                <option value="add_10_gb">➕ افزودن ۱۰ گیگابایت حجم اضافی</option>
                <option value="disable">⏸ غیرفعال‌سازی موقت</option>
                <option value="enable">▶️ فعال‌سازی مجدد</option>
                <option value="delete">🗑 حذف قطعی کاربران انتخاب‌شده</option>
                <option value="delete_unused">🧹 حذف کاربران بدون مصرف از میان انتخاب‌شده‌ها</option>
                <option value="delete_expired">⌛️ حذف کاربران منقضی‌شده از میان انتخاب‌شده‌ها</option>
                <option value="delete_expired_7d">🗓 حذف کاربران منقضی بیش از ۷ روز از میان انتخاب‌شده‌ها</option>
            </select>
            <button type="submit" onclick="return confirm('آیا از اعمال این عملیات روی کاربران انتخاب‌شده مطمئن هستید؟');" class="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition shadow">
                اعمال عملیات
            </button>
        </div>
        <div class="text-[11px] text-slate-400">
            تعداد کل: <?= count($clients) ?> کاربر
        </div>
    </div>

    <div class="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-right text-xs">
                <thead class="bg-slate-800/60 text-slate-300 border-b border-slate-700/60">
                    <tr>
                        <th class="p-3.5 text-center w-10">
                            <input type="checkbox" id="selectAll" onclick="toggleSelectAll(this)" class="rounded bg-slate-800 border-slate-700 text-purple-600 focus:ring-0 cursor-pointer">
                        </th>
                        <th class="p-3.5 font-semibold">شناسه / کاربر</th>
                        <th class="p-3.5 font-semibold">پلن و سرور</th>
                        <th class="p-3.5 font-semibold">ترافیک مصرفی</th>
                        <th class="p-3.5 font-semibold">زمان انقضا</th>
                        <th class="p-3.5 font-semibold">پلن رزرو هوشمند</th>
                        <th class="p-3.5 font-semibold">وضعیت</th>
                        <th class="p-3.5 font-semibold text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/70">
                    <?php if (empty($clients)): ?>
                        <tr>
                            <td colspan="8" class="py-10 text-center text-slate-500">هیچ کاربری با مشخصات انتخابی یافت نشد.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($clients as $c): 
                            $pct = $c['traffic_limit_bytes'] > 0 ? round(($c['traffic_used_bytes'] / $c['traffic_limit_bytes']) * 100, 1) : 0;
                            $rawSub = !empty($c['node_sublink']) ? $c['node_sublink'] : Helpers::subUrl($c['sub_token']);
                            $subUrl = str_contains($rawSub, 'montago-shop.ir') ? preg_replace('#https?://[^/]+#i', 'https://sub.speedur.org:2096', $rawSub) : $rawSub;
                        ?>
                            <tr class="hover:bg-slate-800/30 transition-colors">
                                <td class="p-3.5 text-center">
                                    <input type="checkbox" name="selected_ids[]" value="<?= $c['id'] ?>" class="client-check rounded bg-slate-800 border-slate-700 text-purple-600 focus:ring-0 cursor-pointer">
                                </td>

                                <td class="p-3.5">
                                    <div class="font-bold text-white text-sm font-mono"><?= htmlspecialchars($c['username']) ?></div>
                                    <?php if (!empty($c['customer_name'])): ?>
                                        <div class="text-[11px] font-semibold text-cyan-300 flex items-center gap-1 mt-0.5">
                                            <i class="fa-solid fa-user text-[10px] text-cyan-400"></i>
                                            <span><?= htmlspecialchars($c['customer_name']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="text-[10px] text-slate-400 font-mono mt-0.5 truncate max-w-[140px]"><?= htmlspecialchars($c['uuid']) ?></div>
                                    <?php if (!empty($c['node_sync'])): ?>
                                        <span class="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/40" title="این کلاینت مستقیم روی سرور ساخته شده و از طریق همگام‌سازی در پنل ثبت شده است">
                                            <i class="fa-solid fa-server ml-0.5"></i>مستقیم سرور
                                        </span>
                                    <?php endif; ?>
                                    <?php if (Auth::isAdmin() && !empty($c['reseller_username'])): ?>
                                        <span class="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-purple-950/60 text-purple-300 border border-purple-800/40">نماینده: <?= htmlspecialchars($c['reseller_username']) ?></span>
                                    <?php endif; ?>
                                </td>

                                <td class="p-3.5">
                                    <div class="font-medium text-slate-200"><?= !empty($c['node_sync']) ? 'مستقیم سرور' : htmlspecialchars($c['plan_title'] ?? 'پلن عادی') ?></div>
                                    <div class="text-[11px] text-slate-400 mt-0.5"><?= htmlspecialchars($c['server_name'] ?? 'سرور ابری') ?></div>
                                    <span class="inline-flex items-center gap-1 mt-1 text-[10px] text-purple-300 font-mono bg-purple-950/40 px-1.5 py-0.5 rounded border border-purple-800/30">
                                        <i class="fa-solid fa-users text-[9px]"></i>
                                        <span><?= !empty($c['ip_limit']) && (int)$c['ip_limit'] > 0 ? ((int)$c['ip_limit'] . ' دستگاه') : 'نامحدود' ?></span>
                                    </span>
                                </td>

                                <td class="p-3.5 min-w-[140px]">
                                    <div class="flex items-center justify-between text-[11px] mb-1">
                                        <span class="text-slate-300 font-medium"><?= Helpers::formatBytes($c['traffic_used_bytes']) ?></span>
                                        <span class="text-slate-400"><?= Helpers::formatBytes($c['traffic_limit_bytes']) ?></span>
                                    </div>
                                    <div class="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                                        <div class="h-1.5 rounded-full <?= $pct >= 90 ? 'bg-rose-500' : ($pct >= 75 ? 'bg-amber-500' : 'bg-purple-500') ?>" style="width: <?= min(100, $pct) ?>%"></div>
                                    </div>
                                    <span class="text-[10px] text-slate-400 mt-0.5 block"><?= $pct ?>% مصرف</span>
                                </td>

                                <td class="p-3.5">
                                    <div class="font-medium text-white"><?= Helpers::daysRemaining($c['expire_at']) ?></div>
                                    <span class="text-[10px] text-slate-400 font-mono"><?= $c['expire_at'] ?: 'نامحدود' ?></span>
                                </td>

                                <td class="p-3.5">
                                    <?php if (!empty($c['reserved_id'])): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                                            <i class="fa-solid fa-sparkles text-[9px]"></i>
                                            رزرو: <?= $c['reserved_gb'] ?>GB
                                        </span>
                                    <?php else: ?>
                                        <button type="button" onclick="openReserveModal(<?= $c['id'] ?>, '<?= htmlspecialchars($c['username']) ?>')" class="text-[11px] text-slate-500 hover:text-cyan-400 transition-colors flex items-center gap-1">
                                            <i class="fa-solid fa-plus text-[9px]"></i>
                                            <span>افزودن رزرو</span>
                                        </button>
                                    <?php endif; ?>
                                </td>

                                <td class="p-3.5">
                                    <span class="inline-block px-2 py-0.5 rounded text-[10px] font-semibold <?= $c['status'] === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : ($c['status'] === 'waiting_connect' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : ($c['status'] === 'expired' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-slate-800 text-slate-400')) ?>">
                                        <?= match($c['status']) {
                                            'active' => 'فعال',
                                            'waiting_connect' => 'در انتظار اتصال اول',
                                            'expired' => 'منقضی',
                                            'disabled' => 'غیرفعال',
                                            'never_connected' => 'عدم اتصال',
                                            default => $c['status']
                                        } ?>
                                    </span>
                                </td>

                                <td class="p-3.5 text-center">
                                    <div class="flex items-center justify-center gap-1.5">
                                        <!-- Inspector & QR Modal Button -->
                                        <button type="button" onclick="openInspectModal(<?= $c['id'] ?>, '<?= htmlspecialchars($c['username']) ?>', '<?= $subUrl ?>')" 
                                                class="p-2 bg-slate-800 hover:bg-slate-700 text-purple-300 hover:text-white rounded-lg transition-colors border border-slate-700" title="مشاهده کانفیگ‌ها، ساب‌لینک و بارکد QR">
                                            <i class="fa-solid fa-qrcode"></i>
                                        </button>

                                        <!-- Quick Copy Sublink -->
                                        <button type="button" onclick="copyToClipboard('<?= $subUrl ?>', this)" 
                                                class="p-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white rounded-lg transition-colors border border-slate-700" title="کپی سریع لینک سابسکریپشن">
                                            <i class="fa-solid fa-copy"></i>
                                        </button>

                                        <!-- Edit Service Modal Button -->
                                        <button type="button" onclick='openEditClientModal(<?= json_encode($c) ?>)' 
                                                class="p-2 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white rounded-lg transition-colors border border-slate-700" title="ویرایش مشخصات سرویس">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>

                                        <!-- Renew Modal Button -->
                                        <button type="button" onclick="openRenewModal(<?= $c['id'] ?>, '<?= htmlspecialchars($c['username']) ?>')" 
                                                class="p-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-white rounded-lg transition-colors border border-slate-700" title="تمدید آنی">
                                            <i class="fa-solid fa-rotate"></i>
                                        </button>

                                        <!-- Delete Button -->
                                        <button type="button" onclick="if(confirm('آیا از حذف این کاربر اطمینان دارید؟')) { document.getElementById('deleteIdInput').value = <?= $c['id'] ?>; document.getElementById('deleteForm').submit(); }" class="p-2 bg-slate-800 hover:bg-rose-900/60 text-rose-400 hover:text-rose-200 rounded-lg transition-colors border border-slate-700" title="حذف کاربر">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</form>

<!-- Single Delete Helper Form -->
<form id="deleteForm" action="<?= Helpers::url('clients/delete') ?>" method="POST" class="hidden">
    <?= Helpers::csrfField() ?>
    <input type="hidden" name="client_id" id="deleteIdInput" value="">
</form>

<!-- Modal 1: Client Inspector & Delivery Dialog -->
<div id="inspectModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center p-4 z-50">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button onclick="closeInspectModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center text-lg">
                <i class="fa-solid fa-satellite-dish"></i>
            </div>
            <div>
                <h3 id="inspectUsername" class="text-base font-bold text-white font-mono">user_xxx</h3>
                <div class="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                    <span id="inspectTraffic">-- / --</span>
                    <span>•</span>
                    <span id="inspectDays" class="text-cyan-400">-- روز مانده</span>
                </div>
            </div>
        </div>

        <!-- Credentials Quick Display -->
        <div class="bg-slate-950/60 border border-slate-800 rounded-xl p-3 grid grid-cols-2 gap-3 text-xs mb-3">
            <div>
                <span class="text-slate-400 block text-[10px]">نام کاربری (Username):</span>
                <span id="inspectUserField" class="font-mono font-bold text-white text-xs">--</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px]">کلمه عبور (Password):</span>
                <span id="inspectPassField" class="font-mono font-bold text-purple-300 text-xs">--</span>
            </div>
        </div>

        <!-- Copy Full Customer Delivery Text Button -->
        <button type="button" onclick="copyCustomerDeliveryText(this)" class="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition mb-4">
            <i class="fa-solid fa-share-nodes"></i>
            <span>کپی متن کامل تحویل به مشتری (شامل یوزر، پسورد، ساب‌لینک و ربات)</span>
        </button>

        <!-- Navigation Tabs -->
        <div class="flex border-b border-slate-800 text-xs mb-4">
            <button onclick="switchInspectTab('sub')" id="tabBtnSub" class="px-3 py-2 border-b-2 border-purple-500 text-purple-400 font-bold transition-colors">
                <i class="fa-solid fa-link ml-1"></i> ساب‌لینک و QR
            </button>
            <button onclick="switchInspectTab('apps')" id="tabBtnApps" class="px-3 py-2 border-b-2 border-transparent text-slate-400 hover:text-white font-medium transition-colors">
                <i class="fa-solid fa-mobile-screen ml-1"></i> اتصال سریع اپ‌ها
            </button>
            <button onclick="switchInspectTab('raw')" id="tabBtnRaw" class="px-3 py-2 border-b-2 border-transparent text-slate-400 hover:text-white font-medium transition-colors">
                <i class="fa-solid fa-code ml-1"></i> کانفیگ‌های مجزا
            </button>
        </div>

        <!-- Tab 1: Sublink & QR -->
        <div id="tabSub" class="space-y-4">
            <div class="bg-white p-3 rounded-2xl inline-block shadow-inner mx-auto block text-center w-fit">
                <img id="inspectQrImage" src="" alt="QR" class="w-44 h-44 mx-auto">
            </div>

            <!-- Service Details beneath QR Code -->
            <div class="bg-slate-800/90 border border-slate-700/80 rounded-xl p-3.5 space-y-2.5 text-xs">
                <div class="text-[11px] font-bold text-slate-300 border-b border-slate-700 pb-1.5 flex items-center justify-between">
                    <span><i class="fa-solid fa-circle-info text-cyan-400 ml-1"></i> مشخصات و اطلاعات سرویس</span>
                    <span class="text-[10px] text-slate-400">شناسه اختصاصی کاربر</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-slate-300">
                    <div class="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 block text-[10px] mb-0.5">نام کاربری:</span>
                        <code id="inspectUserField" class="font-bold text-purple-300 select-all">-</code>
                    </div>
                    <div class="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 block text-[10px] mb-0.5">کلمه عبور:</span>
                        <code id="inspectPassField" class="font-bold text-amber-300 select-all">-</code>
                    </div>
                    <div class="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 block text-[10px] mb-0.5">مصرف ترافیک:</span>
                        <span id="inspectTraffic" class="font-bold text-cyan-300">-</span>
                    </div>
                    <div class="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 block text-[10px] mb-0.5">اعتبار زمانی:</span>
                        <span id="inspectDays" class="font-bold text-emerald-300">-</span>
                    </div>
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[11px] text-slate-400">آدرس لینک اشتراک هوشمند (Sublink):</label>
                <div class="flex items-center gap-2">
                    <input type="text" id="inspectSubUrl" readonly class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-300 font-mono text-center select-all">
                    <button onclick="copyToClipboard(document.getElementById('inspectSubUrl').value, this)" class="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs transition-all shadow-md shrink-0">
                        <i class="fa-solid fa-copy"></i>
                    </button>
                </div>
                <a id="inspectLandingBtn" href="#" target="_blank" class="block w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl text-xs font-medium border border-slate-700 transition-colors text-center">
                    <i class="fa-solid fa-arrow-up-right-from-square ml-1"></i>
                    مشاهده صفحه ساب‌لینک اختصاصی کاربر
                </a>
            </div>
        </div>

        <!-- Tab 2: One-Click App Connect -->
        <div id="tabApps" class="hidden space-y-3">
            <p class="text-xs text-slate-400 mb-2">با کلیک روی هر دکمه، اشتراک مستقیماً در نرم‌افزار مربوطه در گوشی یا کامپیوتر باز و ثبت می‌شود:</p>
            
            <a id="btnHiddify" href="#" class="w-full py-3 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white font-bold rounded-xl text-xs flex items-center justify-between px-4 shadow transition">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-rocket text-sm"></i>
                    <span>اتصال خودکار با هیدیفای (Hiddify)</span>
                </span>
                <i class="fa-solid fa-chevron-left text-xs"></i>
            </a>

            <a id="btnV2rayNG" href="#" class="w-full py-3 bg-gradient-to-r from-cyan-700 to-blue-700 hover:from-cyan-600 hover:to-blue-600 text-white font-bold rounded-xl text-xs flex items-center justify-between px-4 shadow transition">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-shield-halved text-sm"></i>
                    <span>اتصال خودکار با V2rayNG</span>
                </span>
                <i class="fa-solid fa-chevron-left text-xs"></i>
            </a>

            <a id="btnSingbox" href="#" class="w-full py-3 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white font-bold rounded-xl text-xs flex items-center justify-between px-4 shadow transition">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-bolt text-sm"></i>
                    <span>اتصال خودکار با Sing-box / Streisand</span>
                </span>
                <i class="fa-solid fa-chevron-left text-xs"></i>
            </a>
        </div>

        <!-- Tab 3: Raw Individual Configs -->
        <div id="tabRaw" class="hidden space-y-3">
            <div id="rawConfigsContainer" class="space-y-3">
                <div class="text-center py-6 text-slate-500">
                    <i class="fa-solid fa-spinner fa-spin text-lg"></i>
                    <span class="block mt-2 text-xs">در حال بارگذاری کانفیگ‌ها...</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2: Renew Subscription -->
<div id="renewModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto modal-overlay">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-5 sm:p-6 shadow-2xl relative my-auto max-h-[88vh] overflow-y-auto modal-box">
        <button onclick="closeRenewModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-base font-bold text-white mb-1">تمدید اشتراک</h3>
        <p class="text-xs text-slate-400 mb-4">کاربر: <span id="renewUsername" class="font-mono text-emerald-400 font-bold"></span></p>

        <form action="<?= Helpers::url('clients/renew') ?>" method="POST" class="space-y-4">
            <?= Helpers::csrfField() ?>
            <input type="hidden" name="client_id" id="renewClientId" value="">

            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">انتخاب پلن جدید جهت تمدید:</label>
                <select name="plan_id" required class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-500">
                    <?php foreach ($plans as $p): ?>
                        <option value="<?= $p['id'] ?>">
                            <?= htmlspecialchars($p['title']) ?> (<?= $p['traffic_gb'] ?>GB / <?= $p['duration_days'] ?> روز) - <?= Helpers::formatMoney($p['reseller_price']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="text-[11px] text-amber-300/80 bg-amber-950/40 border border-amber-900/60 p-3 rounded-xl">
                <i class="fa-solid fa-triangle-exclamation"></i>
                حجم و روزهای پلن جدید به باقیمانده سرویس کاربر اضافه شده و مبلغ پلن از کیف پول کسر می‌گردد.
            </div>

            <button type="submit" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-all shadow-md">
                تایید و تمدید آنی
            </button>
        </form>
    </div>
</div>

<!-- Modal 3: Reserve Plan -->
<div id="reserveModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto modal-overlay">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-5 sm:p-6 shadow-2xl relative my-auto max-h-[88vh] overflow-y-auto modal-box">
        <button onclick="closeReserveModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-base font-bold text-white mb-1">رزرو هوشمند پلن بعدی</h3>
        <p class="text-xs text-slate-400 mb-4">کاربر: <span id="reserveUsername" class="font-mono text-cyan-400 font-bold"></span></p>

        <form action="<?= Helpers::url('clients/reserve') ?>" method="POST" class="space-y-4">
            <?= Helpers::csrfField() ?>
            <input type="hidden" name="client_id" id="reserveClientId" value="">

            <div>
                <label class="block text-xs font-semibold text-slate-300 mb-1.5">انتخاب پلن رزرو:</label>
                <select name="plan_id" required class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500">
                    <?php foreach ($plans as $p): ?>
                        <option value="<?= $p['id'] ?>">
                            <?= htmlspecialchars($p['title']) ?> (<?= $p['traffic_gb'] ?>GB / <?= $p['duration_days'] ?> روز) - <?= Helpers::formatMoney($p['reseller_price']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="text-[11px] text-cyan-300/80 bg-cyan-950/40 border border-cyan-900/60 p-3 rounded-xl">
                <i class="fa-solid fa-circle-info"></i>
                این پلن در صف رزرو قرار می‌گیرد. به محض اینکه حجم بسته فعلی کاربر تمام شود یا تاریخ آن به پایان برسد، سیستم این پلن را به صورت کاملاً خودکار و بدون نیاز به دخالت شما فعال خواهد کرد.
            </div>

            <button type="submit" class="w-full py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-bold rounded-xl text-xs transition-all shadow-md">
                پیش‌خرید و ثبت در صف رزرو
            </button>
        </form>
    </div>
</div>

<script>
    function toggleSelectAll(master) {
        document.querySelectorAll('.client-check').forEach(cb => cb.checked = master.checked);
    }

    let currentClientId = 0;
    let cachedConfigs = null;

    function openInspectModal(id, username, subUrl) {
        currentClientId = id;
        document.getElementById('inspectUsername').innerText = username;
        document.getElementById('inspectSubUrl').value = subUrl;
        document.getElementById('inspectLandingBtn').href = subUrl + '?web=1';
        document.getElementById('inspectQrImage').src = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(subUrl);

        // Setup App Deeplinks
        document.getElementById('btnHiddify').href = 'hiddify://install-sub?url=' + encodeURIComponent(subUrl);
        document.getElementById('btnV2rayNG').href = 'v2rayng://install-config?url=' + encodeURIComponent(subUrl);
        document.getElementById('btnSingbox').href = 'sing-box://import-remote-profile?url=' + encodeURIComponent(subUrl);

        // Fetch configs asynchronously
        fetch('<?= Helpers::url('clients/configs') ?>?id=' + id)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    cachedConfigs = data;
                    document.getElementById('inspectTraffic').innerText = data.client.traffic_used + ' / ' + data.client.traffic_limit;
                    document.getElementById('inspectDays').innerText = data.client.days_remaining;
                    document.getElementById('inspectUserField').innerText = data.client.username;
                    document.getElementById('inspectPassField').innerText = data.client.password;

                    let html = '';
                    const titles = {
                        'vless_reality': 'کانفیگ ضد فیلتر VLESS Reality',
                        'vless_ws': 'کانفیگ CDN WebSocket VLESS',
                        'vmess': 'کانفیگ استاندارد VMess',
                        'trojan': 'کانفیگ ایمن Trojan TLS'
                    };

                    for (const [key, val] of Object.entries(data.configs)) {
                        const title = titles[key] || key;
                        html += `
                            <div class="bg-slate-800/80 border border-slate-700/80 p-3 rounded-xl space-y-1.5 text-xs">
                                <div class="flex items-center justify-between">
                                    <span class="font-bold text-slate-200">${title}</span>
                                    <button onclick="copyToClipboard('${val}', this)" class="px-2.5 py-1 bg-purple-600/30 hover:bg-purple-600 text-purple-300 hover:text-white rounded-lg text-[11px] transition">
                                        <i class="fa-solid fa-copy ml-1"></i> کپی
                                    </button>
                                </div>
                                <input type="text" readonly value="${val}" class="w-full bg-slate-900 border border-slate-700/60 rounded-lg p-2 font-mono text-[10px] text-slate-300 select-all" dir="ltr">
                            </div>
                        `;
                    }
                    document.getElementById('rawConfigsContainer').innerHTML = html;
                }
            })
            .catch(() => {
                document.getElementById('rawConfigsContainer').innerHTML = '<div class="text-rose-400 text-center py-4 text-xs">خطا در دریافت کانفیگ‌ها</div>';
            });

        switchInspectTab('sub');
        const modal = document.getElementById('inspectModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function copyCustomerDeliveryText(btn) {
        if (!cachedConfigs || !cachedConfigs.client) {
            alert('اطلاعات کاربر هنوز کامل بارگذاری نشده است. لطفاً چند لحظه صبر کنید.');
            return;
        }

        const c = cachedConfigs.client;
        let text = `🎉 اشتراک اینترنت آزاد شما آماده استفاده است:

👤 نام کاربری: ${c.username}
🔑 کلمه عبور: ${c.password}
📊 ترافیک مجاز: ${c.traffic_limit}
⏳ اعتبار زمانی: ${c.days_remaining}

🔗 لینک اشتراک هوشمند (Sublink):
${c.sub_url}`;

        if (c.bot_bind_url) {
            text += `\n\n🤖 اتصال خودکار به ربات تلگرام (جهت استعلام حجم و تمدید):\n${c.bot_bind_url}`;
        }

        navigator.clipboard.writeText(text).then(() => {
            const orig = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-check text-emerald-300"></i> متن کامل تحویل کپی شد!';
            setTimeout(() => { btn.innerHTML = orig; }, 2500);
        }).catch(err => {
            alert('خطا در کپی: ' + err);
        });
    }

    function closeInspectModal() {
        const modal = document.getElementById('inspectModal');
        modal.classList.remove('flex');
        modal.classList.add('hidden');
    }

    function switchInspectTab(tab) {
        document.getElementById('tabSub').classList.add('hidden');
        document.getElementById('tabApps').classList.add('hidden');
        document.getElementById('tabRaw').classList.add('hidden');

        document.getElementById('tabBtnSub').className = 'px-3 py-2 border-b-2 border-transparent text-slate-400 hover:text-white font-medium transition-colors';
        document.getElementById('tabBtnApps').className = 'px-3 py-2 border-b-2 border-transparent text-slate-400 hover:text-white font-medium transition-colors';
        document.getElementById('tabBtnRaw').className = 'px-3 py-2 border-b-2 border-transparent text-slate-400 hover:text-white font-medium transition-colors';

        if (tab === 'sub') {
            document.getElementById('tabSub').classList.remove('hidden');
            document.getElementById('tabBtnSub').className = 'px-3 py-2 border-b-2 border-purple-500 text-purple-400 font-bold transition-colors';
        } else if (tab === 'apps') {
            document.getElementById('tabApps').classList.remove('hidden');
            document.getElementById('tabBtnApps').className = 'px-3 py-2 border-b-2 border-purple-500 text-purple-400 font-bold transition-colors';
        } else if (tab === 'raw') {
            document.getElementById('tabRaw').classList.remove('hidden');
            document.getElementById('tabBtnRaw').className = 'px-3 py-2 border-b-2 border-purple-500 text-purple-400 font-bold transition-colors';
        }
    }

    function openRenewModal(id, username) {
        document.getElementById('renewClientId').value = id;
        document.getElementById('renewUsername').innerText = username;
        const modal = document.getElementById('renewModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeRenewModal() {
        const modal = document.getElementById('renewModal');
        modal.classList.remove('flex');
        modal.classList.add('hidden');
    }

    function openReserveModal(id, username) {
        document.getElementById('reserveClientId').value = id;
        document.getElementById('reserveUsername').innerText = username;
        const modal = document.getElementById('reserveModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeReserveModal() {
        const modal = document.getElementById('reserveModal');
        modal.classList.remove('flex');
        modal.classList.add('hidden');
    }

    function openEditClientModal(c) {
        document.getElementById('editClientId').value = c.id;
        document.getElementById('editUsername').value = c.username || '';
        document.getElementById('editPassword').value = c.password || '';
        if (document.getElementById('editCustomerName')) {
            document.getElementById('editCustomerName').value = c.customer_name || '';
        }
        document.getElementById('editServerId').value = c.server_id || '';
        document.getElementById('editPlanId').value = c.plan_id || '';
        document.getElementById('editStatus').value = c.status || 'active';
        
        const limitGb = (c.traffic_limit_bytes / (1024 * 1024 * 1024)).toFixed(2);
        const usedGb = (c.traffic_used_bytes / (1024 * 1024 * 1024)).toFixed(2);
        document.getElementById('editTrafficLimitGb').value = parseFloat(limitGb);
        document.getElementById('editTrafficUsedGb').value = parseFloat(usedGb);
        
        document.getElementById('editExpireAt').value = c.expire_at || '';
        document.getElementById('editTelegramChatId').value = c.telegram_chat_id || '';
        document.getElementById('editIpLimit').value = c.ip_limit ?? 0;
        document.getElementById('editCustomNote').value = c.custom_note || '';

        const modal = document.getElementById('editClientModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeEditClientModal() {
        const modal = document.getElementById('editClientModal');
        modal.classList.remove('flex');
        modal.classList.add('hidden');
    }

    function resetClientUsedTraffic() {
        document.getElementById('editTrafficUsedGb').value = 0;
    }
</script>

<!-- Modal: Edit Client / Service -->
<div id="editClientModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center p-4 z-50">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <button type="button" onclick="closeEditClientModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white transition-colors">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-base font-bold text-white mb-4 flex items-center gap-2 pb-3 border-b border-slate-800">
            <i class="fa-solid fa-pen-to-square text-amber-400"></i>
            <span>ویرایش مشخصات اشتراک و سرویس</span>
        </h3>

        <form action="<?= Helpers::url('clients/update') ?>" method="POST" class="space-y-4 text-xs">
            <?= Helpers::csrfField() ?>
            <input type="hidden" name="client_id" id="editClientId" value="">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">نام کاربری (Username) *</label>
                    <input type="text" name="username" id="editUsername" required dir="ltr" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-xs focus:border-amber-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">کلمه عبور (Password)</label>
                    <input type="text" name="password" id="editPassword" dir="ltr" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-xs focus:border-amber-500 focus:outline-none">
                </div>
            </div>

            <div>
                <label class="block text-slate-300 mb-1 font-semibold flex items-center justify-between">
                    <span class="flex items-center gap-1.5">
                        <i class="fa-solid fa-user text-cyan-400"></i>
                        <span>نام و نام خانوادگی خریدار / مشتری</span>
                    </span>
                    <span class="text-[10px] text-slate-400 font-normal">جهت شناسایی دارنده اکانت</span>
                </label>
                <input type="text" name="customer_name" id="editCustomerName" placeholder="مثلاً: علی رضایی یا شرکت آوا" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:border-amber-500 focus:outline-none">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">وضعیت سرویس</label>
                    <select name="status" id="editStatus" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:border-amber-500 focus:outline-none">
                        <option value="active">فعال (Active)</option>
                        <option value="disabled">غیرفعال (Disabled)</option>
                        <option value="limited">پایان حجم (Limited)</option>
                        <option value="expired">منقضی شده (Expired)</option>
                    </select>
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">سرور / نود اختصاصی</label>
                    <select name="server_id" id="editServerId" required class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:border-amber-500 focus:outline-none">
                        <?php foreach ($servers as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['driver']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">پلن متصل</label>
                    <select name="plan_id" id="editPlanId" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:border-amber-500 focus:outline-none">
                        <option value="">بدون پلن اختصاصی</option>
                        <?php foreach ($plans as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['title']) ?> (<?= $p['traffic_gb'] ?>GB)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 p-3.5 bg-slate-950/60 rounded-xl border border-slate-800">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">سقف کل حجم (گیگابایت - GB)</label>
                    <input type="number" step="0.1" name="traffic_limit_gb" id="editTrafficLimitGb" required min="0" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-center text-xs focus:border-amber-500 focus:outline-none">
                </div>
                <div>
                    <div class="flex items-center justify-between mb-1">
                        <label class="text-slate-300 font-semibold">حجم مصرف‌شده (GB)</label>
                        <button type="button" onclick="resetClientUsedTraffic()" class="text-[10px] text-amber-400 hover:text-amber-300 transition flex items-center gap-1">
                            <i class="fa-solid fa-rotate-left"></i>
                            <span>صفر کردن مصرف</span>
                        </button>
                    </div>
                    <input type="number" step="0.1" name="traffic_used_gb" id="editTrafficUsedGb" min="0" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-center text-xs focus:border-amber-500 focus:outline-none">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">تاریخ و زمان انقضا</label>
                    <input type="text" name="expire_at" id="editExpireAt" placeholder="2026-12-31 23:59:59" dir="ltr" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-xs focus:border-amber-500 focus:outline-none">
                    <span class="text-[10px] text-slate-500 mt-0.5 block">فرمت استاندارد: YYYY-MM-DD HH:MM:SS</span>
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">شناسه چت تلگرام کاربر (جهت نوتیفیکیشن)</label>
                    <input type="text" name="telegram_chat_id" id="editTelegramChatId" dir="ltr" placeholder="123456789" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-xs focus:border-amber-500 focus:outline-none">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">سقف اتصال همزمان (کاربر/دستگاه)</label>
                    <input type="number" name="ip_limit" id="editIpLimit" min="0" placeholder="0 = نامحدود" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-center text-xs focus:border-amber-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">یادداشت داخلی ادمین / نماینده</label>
                    <input type="text" name="custom_note" id="editCustomNote" placeholder="توضیحات اختیاری..." class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white text-xs focus:border-amber-500 focus:outline-none">
                </div>
            </div>

            <div class="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button type="button" onclick="closeEditClientModal()" class="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition">
                    انصراف
                </button>
                <button type="submit" class="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition shadow-md flex items-center gap-2">
                    <i class="fa-solid fa-floppy-disk"></i>
                    <span>ذخیره تغییرات سرویس</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Quick Test Account Creation with Traffic Selection -->
<div id="testAccountModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto modal-overlay">
    <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl relative space-y-4 my-auto max-h-[88vh] overflow-y-auto modal-box">
        <button onclick="closeTestModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white transition">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-base font-bold text-white flex items-center gap-2">
            <i class="fa-solid fa-wand-magic-sparkles text-cyan-400"></i>
            <span>صدور آنی اکانت تست</span>
        </h3>
        <p class="text-xs text-slate-400">حجم ترافیک مورد نظر برای این اکانت تست را تعیین نمایید (مثلاً ۲۰۰ یا ۵۰۰ مگابایت):</p>

        <form action="<?= Helpers::url('clients/test-account') ?>" method="POST" class="space-y-4 text-xs">
            <?= Helpers::csrfField() ?>

            <div>
                <label class="block text-slate-300 mb-1.5 font-semibold">انتخاب سریع حجم ترافیک:</label>
                <div class="grid grid-cols-3 gap-2">
                    <button type="button" onclick="setTestMb(200)" class="py-2 rounded-xl bg-slate-800 hover:bg-cyan-600/30 text-slate-200 hover:text-cyan-300 border border-slate-700 font-mono font-bold text-xs transition">
                        ۲۰۰ مگابایت
                    </button>
                    <button type="button" onclick="setTestMb(500)" class="py-2 rounded-xl bg-slate-800 hover:bg-cyan-600/30 text-slate-200 hover:text-cyan-300 border border-slate-700 font-mono font-bold text-xs transition">
                        ۵۰۰ مگابایت
                    </button>
                    <button type="button" onclick="setTestMb(1024)" class="py-2 rounded-xl bg-slate-800 hover:bg-cyan-600/30 text-slate-200 hover:text-cyan-300 border border-slate-700 font-mono font-bold text-xs transition">
                        ۱ گیگابایت
                    </button>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">حجم تست (مگابایت) *</label>
                    <input type="number" name="traffic_mb" id="test_traffic_mb" value="200" required min="50" max="50000" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-center">
                    <span class="text-[10px] text-slate-400 mt-0.5 block">مثال: 200 یا 500</span>
                </div>
                <div>
                    <label class="block text-slate-300 mb-1 font-semibold">مدت زمان (ساعت) *</label>
                    <input type="number" name="hours" value="24" required min="1" max="720" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-center">
                    <span class="text-[10px] text-slate-400 mt-0.5 block">پیش‌فرض ۲۴ ساعت</span>
                </div>
            </div>

            <div>
                <label class="block text-slate-300 mb-1 font-semibold">سرور مقصد:</label>
                <select name="server_id" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white">
                    <option value="0">⚡️ انتخاب خودکار اولین سرور فعال</option>
                    <?php if (!empty($servers)): ?>
                        <?php foreach ($servers as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= strtoupper($s['driver']) ?>)</option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <button type="submit" class="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs transition shadow-md mt-2 flex items-center justify-center gap-2">
                <i class="fa-solid fa-bolt"></i>
                <span>صدور و فعال‌سازی اکانت تست</span>
            </button>
        </form>
    </div>
</div>

<!-- Modal: Smart Service Optimizer & Cleaner -->
<div id="optimizerModal" class="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 hidden items-center justify-center p-4">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button onclick="closeOptimizerModal()" class="absolute top-4 left-4 text-slate-400 hover:text-white transition">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <div>
            <div class="flex items-center gap-2">
                <div class="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                    <i class="fa-solid fa-broom text-base"></i>
                </div>
                <div>
                    <h3 class="text-base font-bold text-white">مرکز بهینه‌سازی و پاکسازی هوشمند سرویس‌ها</h3>
                    <p class="text-xs text-slate-400 mt-0.5">پاکسازی خودکار از دیتابیس پنل و حذف از نودهای متصل (مرزبان، پاسارگاد، سنایی، X-UI)</p>
                </div>
            </div>
        </div>

        <!-- Live Statistics Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-amber-400 inline-block"></span>
                    بدون مصرف (حجم صفر)
                </div>
                <div class="text-xl font-bold font-mono text-amber-300 mt-1"><?= number_format($optimizerStats['unused'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>

            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-rose-400 inline-block"></span>
                    منقضی بیش از ۷ روز
                </div>
                <div class="text-xl font-bold font-mono text-rose-300 mt-1"><?= number_format($optimizerStats['expired_7d'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>

            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
                    منقضی بیش از ۱۴ روز
                </div>
                <div class="text-xl font-bold font-mono text-rose-400 mt-1"><?= number_format($optimizerStats['expired_14d'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>

            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-rose-600 inline-block"></span>
                    منقضی بیش از ۳۰ روز
                </div>
                <div class="text-xl font-bold font-mono text-rose-500 mt-1"><?= number_format($optimizerStats['expired_30d'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>

            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                    کل منقضی‌ها
                </div>
                <div class="text-xl font-bold font-mono text-red-400 mt-1"><?= number_format($optimizerStats['expired_all'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>

            <div class="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                <div class="text-slate-400 text-[11px] flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-cyan-400 inline-block"></span>
                    تست‌های منقضی
                </div>
                <div class="text-xl font-bold font-mono text-cyan-300 mt-1"><?= number_format($optimizerStats['expired_trials'] ?? 0) ?> <span class="text-xs text-slate-400 font-normal">سرویس</span></div>
            </div>
        </div>

        <div class="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-200/90 leading-relaxed flex items-start gap-2">
            <i class="fa-solid fa-triangle-exclamation text-amber-400 mt-0.5"></i>
            <div>
                <b>هشدار پاکسازی:</b> عملیات بهینه‌سازی غیرقابل بازگشت است. کاربران شناسایی‌شده همزمان از دیتابیس پنل و همچنین از روی سرورهای نود (مرزبان، پاسارگاد و ۳X-UI) به طور کامل حذف خواهند شد تا منابع و حافظه آزاد شوند.
            </div>
        </div>

        <!-- 1-Click Optimization Actions -->
        <div class="space-y-2.5">
            <!-- Purge Unused -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('سرویس‌های بدون مصرف (حجم صفر)');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="unused">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-circle-pause text-amber-400"></i>
                        <span>پاکسازی سرویس‌های بدون مصرف (حجم صفر)</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">اکانت‌هایی که ساخته شده اما کلاینت هیچ ترافیکی مصرف نکرده است</div>
                </div>
                <button type="submit" <?= ($optimizerStats['unused'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['unused'] ?? 0 ?>)</span>
                </button>
            </form>

            <!-- Purge Expired > 7 Days -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('سرویس‌های منقضی بیش از ۷ روز');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="expired_7d">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-clock-rotate-left text-rose-400"></i>
                        <span>پاکسازی اکانت‌های منقضی بیش از ۷ روز (۱ هفته)</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">بهترین گزینه برای آزاد کردن دوره‌ای منابع و ترافیک سرورها</div>
                </div>
                <button type="submit" <?= ($optimizerStats['expired_7d'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['expired_7d'] ?? 0 ?>)</span>
                </button>
            </form>

            <!-- Purge Expired > 14 Days -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('سرویس‌های منقضی بیش از ۱۴ روز');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="expired_14d">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-calendar-xmark text-rose-500"></i>
                        <span>پاکسازی اکانت‌های منقضی بیش از ۱۴ روز (۲ هفته)</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">اکانت‌های متروکه‌ای که پس از دو هفته تمدید نشده‌اند</div>
                </div>
                <button type="submit" <?= ($optimizerStats['expired_14d'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-rose-700 hover:bg-rose-600 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['expired_14d'] ?? 0 ?>)</span>
                </button>
            </form>

            <!-- Purge Expired > 30 Days -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('سرویس‌های منقضی بیش از ۳۰ روز');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="expired_30d">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-skull-crossbones text-rose-600"></i>
                        <span>پاکسازی اکانت‌های منقضی بیش از ۳۰ روز (۱ ماه)</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">آزادسازی قطعی اکانت‌های تاریخ‌گذشته قدیمی</div>
                </div>
                <button type="submit" <?= ($optimizerStats['expired_30d'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-rose-800 hover:bg-rose-700 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['expired_30d'] ?? 0 ?>)</span>
                </button>
            </form>

            <!-- Purge Expired Trials -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('اکانت‌های تست رایگان منقضی');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="trials_expired">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-vial text-cyan-400"></i>
                        <span>پاکسازی اکانت‌های تست منقضی</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">حذف تست‌های ۲۴ ساعته یا موقتی که به اتمام رسیده‌اند</div>
                </div>
                <button type="submit" <?= ($optimizerStats['expired_trials'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-cyan-700 hover:bg-cyan-600 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['expired_trials'] ?? 0 ?>)</span>
                </button>
            </form>

            <!-- Purge All Expired -->
            <form action="<?= Helpers::url('clients/optimize-purge') ?>" method="POST" onsubmit="return confirmPurge('کلیه سرویس‌های منقضی‌شده');" class="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl border border-slate-700/60 transition">
                <?= Helpers::csrfField() ?>
                <input type="hidden" name="purge_type" value="expired_all">
                <div class="text-xs">
                    <div class="font-bold text-white flex items-center gap-1.5">
                        <i class="fa-solid fa-fire text-red-500"></i>
                        <span>پاکسازی کلیه سرویس‌های منقضی‌شده (همه تاریخ‌ها)</span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5">حذف فوری تمامی سرویس‌هایی که وضعیت آنها منقضی یا تاریخشان به اتمام رسیده است</div>
                </div>
                <button type="submit" <?= ($optimizerStats['expired_all'] ?? 0) === 0 ? 'disabled' : '' ?> class="px-4 py-2 bg-red-700 hover:bg-red-600 disabled:opacity-40 disabled:pointer-events-none text-white font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-trash-can"></i>
                    <span>حذف (<?= $optimizerStats['expired_all'] ?? 0 ?>)</span>
                </button>
            </form>
        </div>

        <div class="pt-2 flex justify-end">
            <button type="button" onclick="closeOptimizerModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition">
                بستن پنجره
            </button>
        </div>
    </div>
</div>

<script>
function openTestModal() {
    var m = document.getElementById('testAccountModal');
    if (m) {
        m.classList.remove('hidden');
        m.classList.add('flex');
    }
}
function closeTestModal() {
    var m = document.getElementById('testAccountModal');
    if (m) {
        m.classList.remove('flex');
        m.classList.add('hidden');
    }
}
function setTestMb(mb) {
    var inp = document.getElementById('test_traffic_mb');
    if (inp) inp.value = mb;
}

function openOptimizerModal() {
    var m = document.getElementById('optimizerModal');
    if (m) {
        m.classList.remove('hidden');
        m.classList.add('flex');
    }
}
function closeOptimizerModal() {
    var m = document.getElementById('optimizerModal');
    if (m) {
        m.classList.remove('flex');
        m.classList.add('hidden');
    }
}
function confirmPurge(label) {
    return confirm('هشدار نهایی: آیا از حذف دائمی «' + label + '» از روی دیتابیس پنل و کلیه سرورها اطمینان کامل دارید؟\n\nاین عملیات قابل بازگشت نیست.');
}
</script>

<?php
require __DIR__ . '/../layout/footer.php';
?>
