<?php
require_once __DIR__ . '/../config.php';

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            try {
                if (DB_DRIVER === 'sqlite') {
                    if (!extension_loaded('pdo_sqlite')) {
                        throw new Exception("اکستنشن pdo_sqlite روی هاست فعال نیست. لطفاً از طریق install.php دیتابیس MySQL سی‌پنل را متصل کنید.");
                    }
                    $dbDir = dirname(SQLITE_PATH);
                    if (!is_dir($dbDir)) {
                        mkdir($dbDir, 0777, true);
                    }
                    $isNew = !file_exists(SQLITE_PATH);
                    self::$instance = new PDO('sqlite:' . SQLITE_PATH);
                    self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                    self::$instance->exec('PRAGMA foreign_keys = ON;');
                    
                    if ($isNew || filesize(SQLITE_PATH) === 0) {
                        self::initializeSqliteSchema(self::$instance);
                    }
                } else {
                    $hosts = [DB_HOST];
                    if (DB_HOST === 'localhost') {
                        $hosts[] = '127.0.0.1';
                    } elseif (DB_HOST === '127.0.0.1') {
                        $hosts[] = 'localhost';
                    }

                    $opts = [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                    ];

                    $lastEx = null;
                    foreach ($hosts as $h) {
                        for ($attempt = 0; $attempt < 3; $attempt++) {
                            try {
                                $dsn = "mysql:host={$h};port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $opts);
                                break 2;
                            } catch (Throwable $pe) {
                                $lastEx = $pe;
                                usleep(150000); // 150ms backoff
                            }
                        }
                    }
                    if (self::$instance === null) {
                        throw $lastEx ?: new Exception("عدم امکان اتصال به MySQL");
                    }
                }
                self::ensureExtendedTablesExist(self::$instance);
            } catch (Throwable $e) {
                if (defined('CONNECTIX_REPAIR') || defined('CONNECTIX_INSTALL') || (defined('CONNECTIX_NO_DIE') && CONNECTIX_NO_DIE)) {
                    throw $e;
                }
                die("<!DOCTYPE html><html lang='fa' dir='rtl'><head><meta charset='UTF-8'><title>خطای پایگاه داده</title><script src='https://cdn.tailwindcss.com'></script><style>@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap'); *{font-family:'Vazirmatn',sans-serif;}</style></head><body class='bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center p-4'><div class='bg-slate-900 border border-rose-900/50 p-8 rounded-2xl max-w-md w-full text-center shadow-2xl space-y-4'><div class='w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center text-3xl'>⚠️</div><h2 class='text-lg font-bold text-white'>خطا در ارتباط با دیتابیس</h2><p class='text-xs text-rose-300 leading-relaxed'>" . htmlspecialchars($e->getMessage()) . "</p><div class='pt-2'><a href='install.php?reinstall=1' class='inline-block w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs transition-all shadow-md'>ورود به نصب‌کننده و تنظیم مجدد دیتابیس</a></div></div></body></html>");
            }
        }
        return self::$instance;
    }

    public static function safeAddColumn(PDO $pdo, string $table, string $column, string $definition): void {
        try {
            $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
            if ($driver === 'mysql') {
                $check = $pdo->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'")->fetch();
                if (!$check) {
                    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
                }
            } else {
                $cols = $pdo->query("PRAGMA table_info(`{$table}`)")->fetchAll(PDO::FETCH_ASSOC);
                $names = array_column($cols, 'name');
                if (!in_array($column, $names)) {
                    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
                }
            }
        } catch (Throwable $e) {}
    }

    public static function ensureExtendedTablesExist(PDO $pdo): void {
        try {
            $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
            $isSqlite = ($driver === 'sqlite');
            $autoInc = $isSqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT AUTO_INCREMENT PRIMARY KEY';

            // 1. Auxiliary Tables
            $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
                setting_key VARCHAR(64) PRIMARY KEY,
                setting_value TEXT NULL
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS bot_orders (
                id $autoInc,
                order_code VARCHAR(32) UNIQUE,
                reseller_id INT NULL DEFAULT 1,
                bot_token VARCHAR(255) NULL,
                user_tg_id VARCHAR(64) NOT NULL,
                user_tg_name VARCHAR(128) NULL,
                user_tg_username VARCHAR(128) NULL,
                order_type VARCHAR(32) DEFAULT 'new',
                plan_id INT NULL,
                server_id INT NULL,
                target_username VARCHAR(64) NULL,
                amount BIGINT DEFAULT 0,
                coupon_code VARCHAR(64) NULL,
                discount_amount BIGINT DEFAULT 0,
                payment_method VARCHAR(32) DEFAULT 'card',
                payment_status VARCHAR(32) DEFAULT 'pending_receipt',
                receipt_photo_id VARCHAR(255) NULL,
                receipt_note TEXT NULL,
                client_id INT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS bot_sessions (
                tg_id VARCHAR(64) NOT NULL,
                reseller_id INT NOT NULL DEFAULT 1,
                step VARCHAR(64) NULL,
                data TEXT NULL,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (tg_id, reseller_id)
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS bot_users (
                id $autoInc,
                reseller_id INT NULL DEFAULT 1,
                tg_id VARCHAR(64) UNIQUE NOT NULL,
                first_name VARCHAR(128) NULL,
                last_name VARCHAR(128) NULL,
                username VARCHAR(128) NULL,
                phone VARCHAR(32) NULL,
                referred_by VARCHAR(64) NULL,
                referral_balance BIGINT DEFAULT 0,
                referral_count INT DEFAULT 0,
                is_blocked TINYINT(1) DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_active_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS trial_logs (
                id $autoInc,
                user_id INT NULL,
                reseller_id INT NULL DEFAULT 1,
                telegram_id VARCHAR(64) NULL,
                ip_address VARCHAR(64) NULL,
                client_id INT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS lucky_wheel_logs (
                id $autoInc,
                user_tg_id VARCHAR(64) NOT NULL,
                reward_type VARCHAR(32) NOT NULL,
                reward_value INT NOT NULL,
                reward_text VARCHAR(255) NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS wallet_logs (
                id $autoInc,
                tg_id VARCHAR(64) NOT NULL,
                amount BIGINT NOT NULL,
                balance_after BIGINT NOT NULL,
                type VARCHAR(32) NOT NULL,
                description VARCHAR(255) NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS crypto_payments (
                id $autoInc,
                user_id INT NULL,
                reseller_id INT NULL DEFAULT 1,
                order_id INT NULL,
                currency VARCHAR(16) DEFAULT 'USDT',
                network VARCHAR(16) DEFAULT 'TRC20',
                expected_amount_usdt DECIMAL(10,2) DEFAULT 0.00,
                toman_amount BIGINT DEFAULT 0,
                wallet_address VARCHAR(128) NOT NULL,
                tx_hash VARCHAR(128) NULL,
                status VARCHAR(32) DEFAULT 'pending',
                admin_notes TEXT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS app_guides (
                id $autoInc,
                platform VARCHAR(32) NOT NULL,
                app_name VARCHAR(128) NOT NULL,
                download_url VARCHAR(255) NOT NULL,
                guide_url VARCHAR(255) NULL,
                description TEXT NULL,
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS coupons (
                id $autoInc,
                code VARCHAR(64) UNIQUE NOT NULL,
                discount_percent INT DEFAULT 10,
                max_uses INT DEFAULT 100,
                used_count INT DEFAULT 0,
                expire_at DATETIME NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS reseller_plans (
                id $autoInc,
                reseller_id INT NOT NULL,
                plan_id INT NOT NULL,
                custom_title VARCHAR(128) NULL,
                custom_category VARCHAR(64) DEFAULT 'پیش‌فرض',
                retail_price BIGINT NOT NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS reseller_applications (
                id $autoInc,
                user_tg_id VARCHAR(64) NOT NULL,
                user_tg_name VARCHAR(128) NULL,
                user_tg_username VARCHAR(128) NULL,
                brand_name VARCHAR(128) NOT NULL,
                contact_info VARCHAR(128) NOT NULL,
                preferred_username VARCHAR(64) NOT NULL,
                estimated_sales VARCHAR(64) NULL,
                experience_notes TEXT NULL,
                status VARCHAR(32) DEFAULT 'pending',
                approved_user_id INT NULL,
                admin_notes TEXT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS tickets (
                id $autoInc,
                user_id INT NOT NULL,
                subject VARCHAR(255) NOT NULL,
                department VARCHAR(64) DEFAULT 'support',
                priority VARCHAR(32) DEFAULT 'medium',
                status VARCHAR(32) DEFAULT 'open',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS ticket_messages (
                id $autoInc,
                ticket_id INT NOT NULL,
                sender_id INT NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
                id $autoInc,
                name VARCHAR(128) NOT NULL,
                slug VARCHAR(64) UNIQUE NOT NULL,
                type VARCHAR(32) DEFAULT 'both',
                icon VARCHAR(64) DEFAULT 'fa-server',
                badge_color VARCHAR(32) DEFAULT 'purple',
                description TEXT NULL,
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS activity_logs (
                id $autoInc,
                user_id INT NULL,
                action VARCHAR(64) NOT NULL,
                entity_type VARCHAR(64) NULL,
                entity_id VARCHAR(64) NULL,
                description TEXT NOT NULL,
                ip_address VARCHAR(45) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            // Time-series snapshots for dashboard trend charts (72h sparklines)
            $pdo->exec("CREATE TABLE IF NOT EXISTS metrics (
                id $autoInc,
                ts DATETIME NOT NULL,
                active_clients INT DEFAULT 0,
                total_clients INT DEFAULT 0,
                online_nodes INT DEFAULT 0,
                total_nodes INT DEFAULT 0,
                traffic_used_total BIGINT DEFAULT 0,
                traffic_limit_total BIGINT DEFAULT 0
            )");

            // 2. Safe Column Additions for Core Tables
            $userCols = [
                'telegram_bot_token' => 'VARCHAR(255) NULL',
                'telegram_bot_username' => 'VARCHAR(128) NULL',
                'telegram_admin_chat_id' => 'VARCHAR(64) NULL',
                'brand_name' => 'VARCHAR(128) NULL',
                'logo_url' => 'VARCHAR(255) NULL',
                'theme_color' => "VARCHAR(32) DEFAULT 'violet'",
                'card_number' => 'VARCHAR(32) NULL',
                'card_holder' => 'VARCHAR(128) NULL',
                'card_shaba' => 'VARCHAR(34) NULL',
                'zarinpal_merchant' => 'VARCHAR(64) NULL',
                'support_username' => 'VARCHAR(128) NULL',
                'welcome_message' => 'TEXT NULL',
                'custom_domain' => 'VARCHAR(128) NULL',
                'telegram_channel' => 'VARCHAR(128) NULL',
                'credit_limit' => 'BIGINT DEFAULT 0',
                'auto_tier_enabled' => 'TINYINT(1) DEFAULT 1',
                'tier_level' => "VARCHAR(32) DEFAULT 'bronze'",
                'parent_reseller_id' => 'INT NULL DEFAULT NULL',
                'commission_percent' => 'INT DEFAULT 10',
                'crypto_wallet_address' => 'VARCHAR(128) NULL',
                'crypto_network' => "VARCHAR(32) DEFAULT 'TRC20'",
                'total_spent' => 'BIGINT DEFAULT 0',
                'telegram_chat_id' => 'VARCHAR(64) NULL',
                'magic_login_token' => 'VARCHAR(64) NULL',
                'magic_login_expires' => 'DATETIME NULL',
                'panel_password_display' => 'VARCHAR(128) NULL'
            ];
            foreach ($userCols as $c => $d) {
                self::safeAddColumn($pdo, 'users', $c, $d);
            }

            $orderCols = [
                'reseller_id' => 'INT NULL DEFAULT 1',
                'bot_token' => 'VARCHAR(255) NULL',
                'coupon_code' => 'VARCHAR(64) NULL',
                'discount_amount' => 'BIGINT DEFAULT 0'
            ];
            foreach ($orderCols as $c => $d) {
                self::safeAddColumn($pdo, 'bot_orders', $c, $d);
            }

            $botUserCols = [
                'referred_by' => 'VARCHAR(64) NULL',
                'referral_balance' => 'BIGINT DEFAULT 0',
                'referral_count' => 'INT DEFAULT 0',
                'wallet_balance' => 'BIGINT DEFAULT 0'
            ];
            foreach ($botUserCols as $c => $d) {
                self::safeAddColumn($pdo, 'bot_users', $c, $d);
            }

            $clientCols = [
                'customer_name' => 'VARCHAR(128) NULL',
                'updated_at' => 'DATETIME NULL',
                'alert_80_sent' => 'TINYINT(1) DEFAULT 0',
                'alert_95_sent' => 'TINYINT(1) DEFAULT 0',
                'alert_exp_sent' => 'TINYINT(1) DEFAULT 0',
                'alert_final_sent' => 'TINYINT(1) DEFAULT 0',
                'telegram_chat_id' => 'VARCHAR(64) NULL',
                'ip_limit' => 'INT DEFAULT 0',
                'max_devices' => 'INT DEFAULT 0',
                'start_on_first_use' => 'TINYINT(1) DEFAULT 0',
                'first_connected_at' => 'DATETIME NULL',
                'duration_days' => 'INT DEFAULT 30',
                'node_sublink' => 'TEXT NULL',
                'node_sync' => 'TINYINT(1) DEFAULT 0',
                'custom_note' => 'TEXT NULL'
            ];
            foreach ($clientCols as $c => $d) {
                self::safeAddColumn($pdo, 'clients', $c, $d);
            }

            $serverCols = [
                'api_token' => 'TEXT NULL',
                'health_status' => "VARCHAR(32) DEFAULT 'online'",
                'latency_ms' => 'INT DEFAULT 0',
                'last_checked_at' => 'DATETIME NULL',
                'error_message' => 'TEXT NULL',
                'category_id' => 'INT NULL DEFAULT NULL',
                'config_template' => 'TEXT NULL',
                'selected_inbounds' => 'TEXT NULL'
            ];
            foreach ($serverCols as $c => $d) {
                self::safeAddColumn($pdo, 'server_nodes', $c, $d);
            }

            $planCols = [
                'show_in_bot' => 'TINYINT(1) DEFAULT 1',
                'category' => "VARCHAR(64) DEFAULT '۱ ماهه'",
                'ip_limit' => 'INT DEFAULT 0',
                'max_devices' => 'INT DEFAULT 0',
                'start_on_first_use' => 'TINYINT(1) DEFAULT 0',
                'server_id' => 'INT NULL DEFAULT NULL',
                'category_id' => 'INT NULL DEFAULT NULL'
            ];
            foreach ($planCols as $c => $d) {
                self::safeAddColumn($pdo, 'plans', $c, $d);
            }

            $isMysql = ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql');
            if ($isMysql) {
                try {
                    $pdo->exec("ALTER TABLE `plans` MODIFY COLUMN `traffic_gb` DECIMAL(10,3) NOT NULL DEFAULT 1.000");
                    $pdo->exec("ALTER TABLE `reserved_plans` MODIFY COLUMN `traffic_gb` DECIMAL(10,3) NOT NULL DEFAULT 1.000");
                } catch (Throwable $e) {}
            }

            // Sync clients ip_limit to match plan if plan is unlimited (ip_limit=0)
            try {
                if ($isMysql) {
                    $pdo->exec("ALTER TABLE `plans` ALTER COLUMN `ip_limit` SET DEFAULT 0");
                    $pdo->exec("ALTER TABLE `plans` ALTER COLUMN `max_devices` SET DEFAULT 0");
                    $pdo->exec("ALTER TABLE `clients` ALTER COLUMN `ip_limit` SET DEFAULT 0");
                    $pdo->exec("ALTER TABLE `clients` ALTER COLUMN `max_devices` SET DEFAULT 0");
                    $pdo->exec("UPDATE clients c INNER JOIN plans p ON c.plan_id = p.id SET c.ip_limit = p.ip_limit, c.max_devices = p.max_devices WHERE p.ip_limit = 0 AND c.ip_limit = 2");
                } else {
                    $pdo->exec("UPDATE clients SET ip_limit = 0, max_devices = 0 WHERE ip_limit = 2 AND plan_id IN (SELECT id FROM plans WHERE ip_limit = 0)");
                }
            } catch (Throwable $e) {}

            // Auto-disable mock servers and detach them from plans if at least one real server is active
            try {
                $hasRealServer = (int)$pdo->query("SELECT COUNT(*) FROM server_nodes WHERE driver != 'mock' AND is_active = 1")->fetchColumn();
                if ($hasRealServer > 0) {
                    $pdo->exec("UPDATE server_nodes SET is_active = 0 WHERE driver = 'mock'");
                    $pdo->exec("UPDATE plans SET server_id = NULL WHERE server_id IN (SELECT id FROM server_nodes WHERE driver = 'mock')");
                }
            } catch (Throwable $e) {}

            // Seed Default Categories if empty
            try {
                $catCount = (int)$pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
                if ($catCount === 0) {
                    $defaultCats = [
                        ['پیش‌فرض (استاندارد)', 'default', 'both', 'fa-globe', 'purple', 'خوشه سرورها و پلن‌های استاندارد بین‌الملل', 1],
                        ['سرورهای VIP و پرسرعت', 'vip', 'servers', 'fa-crown', 'amber', 'سرورهای بهینه‌شده با پهنای باند اختصاصی و پینگ پایین', 2],
                        ['سرورهای اقتصادی (Economic)', 'economic', 'both', 'fa-tag', 'blue', 'پلن‌های باصرفه و اقتصادی جهت وب‌گردی روزمره', 3],
                        ['ایران اکسس (ملی و نامحدود)', 'iran_access', 'both', 'fa-shield-halved', 'emerald', 'سرورهای با دسترسی به سایت‌های داخلی و ترافیک نامحدود', 4],
                        ['مخصوص بازی و گیمینگ (Gaming)', 'gaming', 'servers', 'fa-gamepad', 'cyan', 'سرورهای تونل‌شده بدون نوسان و کمترین زمان پاسخگویی', 5],
                        ['پلن‌های ۱ ماهه', 'period_1m', 'plans', 'fa-calendar-days', 'purple', 'اشتراک‌های استاندارد ۳۰ روزه', 10],
                        ['پلن‌های ۲ ماهه', 'period_2m', 'plans', 'fa-calendar-week', 'blue', 'اشتراک‌های میان‌مدت ۶۰ روزه', 11],
                        ['پلن‌های ۳ ماهه', 'period_3m', 'plans', 'fa-calendar-check', 'amber', 'اشتراک‌های فصلی ۹۰ روزه با تخفیف', 12],
                        ['پلن‌های ۶ ماهه و سالانه', 'period_long', 'plans', 'fa-calendar-plus', 'emerald', 'اشتراک‌های بلندمدت با بیشترین صرفه اقتصادی', 13],
                        ['پلن‌های نامحدود / حجمی', 'unlimited_custom', 'plans', 'fa-infinity', 'cyan', 'پلن‌های با ترافیک بالا یا نامحدود زمانی', 14],
                    ];
                    $stmtCat = $pdo->prepare("INSERT INTO categories (name, slug, type, icon, badge_color, description, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    foreach ($defaultCats as $dc) {
                        $stmtCat->execute($dc);
                    }
                } else {
                    // Ensure plan categories also exist if only servers were seeded
                    $planCatCount = (int)$pdo->query("SELECT COUNT(*) FROM categories WHERE type IN ('plans', 'plan')")->fetchColumn();
                    if ($planCatCount === 0) {
                        $defaultPlanCats = [
                            ['پلن‌های ۱ ماهه', 'period_1m', 'plans', 'fa-calendar-days', 'purple', 'اشتراک‌های استاندارد ۳۰ روزه', 10],
                            ['پلن‌های ۲ ماهه', 'period_2m', 'plans', 'fa-calendar-week', 'blue', 'اشتراک‌های میان‌مدت ۶۰ روزه', 11],
                            ['پلن‌های ۳ ماهه', 'period_3m', 'plans', 'fa-calendar-check', 'amber', 'اشتراک‌های فصلی ۹۰ روزه با تخفیف', 12],
                            ['پلن‌های ۶ ماهه و سالانه', 'period_long', 'plans', 'fa-calendar-plus', 'emerald', 'اشتراک‌های بلندمدت با بیشترین صرفه اقتصادی', 13],
                            ['پلن‌های نامحدود / حجمی', 'unlimited_custom', 'plans', 'fa-infinity', 'cyan', 'پلن‌های با ترافیک بالا یا نامحدود زمانی', 14],
                        ];
                        $stmtCat = $pdo->prepare("INSERT INTO categories (name, slug, type, icon, badge_color, description, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        foreach ($defaultPlanCats as $dpc) {
                            $stmtCat->execute($dpc);
                        }
                    }
                }
            } catch (Throwable $e) {}

            // 3. Seed Default App Guides if empty or ensure proprietary Connectix apps are present
            try {
                $appCount = (int)$pdo->query("SELECT COUNT(*) FROM app_guides")->fetchColumn();
                if ($appCount === 0) {
                    $defaultApps = [
                        ['android', '🚀 Connectix Android (اپلیکیشن اختصاصی - پیشنهادی)', 'https://github.com/hojjatrad/panelconnectix/releases/download/v3.5.8/Connectix-Android-Universal.apk', '', 'نرم‌افزار رسمی و اختصاصی با ورود آسان تنها با نام کاربری و پسورد، بدون نیاز به کانفیگ دستی و تست خودکار پینگ', 0],
                        ['android', 'v2rayNG (پیشنهادی اندروید)', 'https://github.com/2dust/v2rayNG/releases', 'https://t.me/connectix/79', 'پایدارترین کلاینت اندروید با قابلیت اتصال خودکار و پشتیبانی از همه پروتکل‌ها', 1],
                        ['android', 'NapsternetV (کلاینت دوم اندروید)', 'https://play.google.com/store/apps/details?id=com.napsternetlabs.napsternetv', '', 'نرم‌افزار کمکی برای اینترنت‌های با اختلال بالا', 2],
                        ['windows', '🚀 Connectix Windows (نرم‌افزار اختصاصی ویندوز - پیشنهادی)', 'https://github.com/hojjatrad/panelconnectix/releases/download/v3.5.8/Connectix-Windows-x64.zip', '', 'کلاینت اختصاصی ویندوز با تونل کل ترافیک سیستم (VPN Mode) و اتصال ۱ کلیک فوق‌العاده سریع', 0],
                        ['windows', 'NekoRay (پیشنهادی ویندوز)', 'https://github.com/MatsuriDayo/nekoray/releases', '', 'دارای حالت System Proxy و VPN Mode برای کل ترافیک ویندوز', 1],
                        ['windows', 'v2rayN (کلاینت کلاسیک ویندوز)', 'https://github.com/2dust/v2rayN/releases', '', 'پشتیبانی از Reality و Xray Core', 2],
                        ['ios', 'Streisand (پیشنهادی آیفون و آیپد)', 'https://apps.apple.com/app/streisand/id6450534064', '', 'رایگان، بسیار سریع و سازگار با اینترنت‌های همراه اول و ایرانسل', 1],
                        ['ios', 'V2Box (کلاینت جایگزین iOS)', 'https://apps.apple.com/app/v2box-v2ray-client/id6446814042', '', 'پشتیبانی کامل از ساب‌لینک هوشمند و پینگ تست آنی', 2],
                        ['macos', 'FoXray (مک‌بوک)', 'https://apps.apple.com/app/foxray/id6448898396', '', 'کلاینت رسمی و بسیار سبک سیستم‌عامل macOS', 1]
                    ];
                    $stmtApp = $pdo->prepare("INSERT INTO app_guides (platform, app_name, download_url, guide_url, description, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
                    foreach ($defaultApps as $da) {
                        $stmtApp->execute($da);
                    }
                } else {
                    // Ensure proprietary Connectix apps exist in app_guides
                    $cxCount = (int)$pdo->query("SELECT COUNT(*) FROM app_guides WHERE app_name LIKE '%Connectix%'")->fetchColumn();
                    if ($cxCount === 0) {
                        $stmtIns = $pdo->prepare("INSERT INTO app_guides (platform, app_name, download_url, guide_url, description, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
                        $stmtIns->execute([
                            'android',
                            '🚀 Connectix Android (اپلیکیشن اختصاصی - پیشنهادی)',
                            'https://github.com/hojjatrad/panelconnectix/releases/download/v3.5.8/Connectix-Android-Universal.apk',
                            '',
                            'نرم‌افزار رسمی و اختصاصی با ورود آسان تنها با نام کاربری و پسورد، بدون نیاز به کانفیگ دستی و تست خودکار پینگ',
                            0
                        ]);
                        $stmtIns->execute([
                            'windows',
                            '🚀 Connectix Windows (نرم‌افزار اختصاصی ویندوز - پیشنهادی)',
                            'https://github.com/hojjatrad/panelconnectix/releases/download/v3.5.8/Connectix-Windows-x64.zip',
                            '',
                            'کلاینت اختصاصی ویندوز با تونل کل ترافیک سیستم (VPN Mode) و اتصال ۱ کلیک فوق‌العاده سریع',
                            0
                        ]);
                    }
                }
            } catch (Throwable $e) {}

            // 4. Seed Default Coupons if empty
            try {
                $couponCount = (int)$pdo->query("SELECT COUNT(*) FROM coupons")->fetchColumn();
                if ($couponCount === 0) {
                    $pdo->exec("INSERT INTO coupons (code, discount_percent, max_uses, used_count, is_active) VALUES ('WELCOME10', 10, 100, 0, 1)");
                    $pdo->exec("INSERT INTO coupons (code, discount_percent, max_uses, used_count, is_active) VALUES ('VIP20', 20, 50, 0, 1)");
                }
            } catch (Throwable $e) {}

            // 5. Ensure Referrals Table & Columns
            $isMysql = ($driver === 'mysql');
            $refTableSql = $isMysql
                ? "CREATE TABLE IF NOT EXISTS `referrals` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `referrer_id` INT NOT NULL,
                    `referred_id` INT NOT NULL,
                    `order_id` INT NULL,
                    `commission_amount` BIGINT DEFAULT 0,
                    `status` VARCHAR(32) DEFAULT 'completed',
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
                : "CREATE TABLE IF NOT EXISTS referrals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    referrer_id INTEGER NOT NULL,
                    referred_id INTEGER NOT NULL,
                    order_id INTEGER NULL,
                    commission_amount INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'completed',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );";
            $pdo->exec($refTableSql);

            // Columns for Users
            $userCols = [
                'two_factor_secret' => 'VARCHAR(64) NULL',
                'two_factor_enabled' => 'TINYINT(1) DEFAULT 0',
                'referral_code' => 'VARCHAR(32) NULL',
                'referred_by' => 'INT NULL DEFAULT NULL'
            ];
            foreach ($userCols as $c => $d) {
                self::safeAddColumn($pdo, 'users', $c, $d);
            }

            // Columns for Transactions
            $txCols = [
                'receipt_image' => 'VARCHAR(255) NULL',
                'ocr_data' => 'TEXT NULL',
                'payment_method' => "VARCHAR(32) DEFAULT 'manual'",
                'txid' => 'VARCHAR(128) NULL',
                'crypto_amount' => 'VARCHAR(32) NULL',
                'crypto_currency' => 'VARCHAR(16) NULL'
            ];
            foreach ($txCols as $c => $d) {
                self::safeAddColumn($pdo, 'transactions', $c, $d);
            }

            // AI Assistant (v5.4.0): knowledge base, call logs, reseller charged subscriptions
            $pdo->exec("CREATE TABLE IF NOT EXISTS ai_knowledge (
                id $autoInc,
                title VARCHAR(191) NOT NULL,
                keywords VARCHAR(255) NULL,
                category VARCHAR(64) DEFAULT 'فنی',
                content TEXT NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS ai_logs (
                id $autoInc,
                ticket_id INT NULL,
                stage VARCHAR(32) DEFAULT 'draft',
                provider VARCHAR(32) NULL,
                model VARCHAR(128) NULL,
                status VARCHAR(32) DEFAULT 'draft',
                category VARCHAR(64) NULL,
                confidence FLOAT DEFAULT 0,
                is_sensitive TINYINT(1) DEFAULT 0,
                needs_human TINYINT(1) DEFAULT 0,
                answer TEXT NULL,
                latency_ms INT DEFAULT 0,
                error TEXT NULL,
                accepted TINYINT(1) DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            foreach (['idx_ai_logs_ticket', 'idx_ai_logs_created'] as $aiIdx) {
                $col = ($aiIdx === 'idx_ai_logs_ticket') ? 'ticket_id' : 'created_at';
                try {
                    $pdo->exec("CREATE INDEX IF NOT EXISTS {$aiIdx} ON ai_logs ({$col})");
                } catch (Throwable $e) {
                    try { $pdo->exec("CREATE INDEX {$aiIdx} ON ai_logs ({$col})"); } catch (Throwable $e2) {}
                }
            }

            $pdo->exec("CREATE TABLE IF NOT EXISTS ai_subscriptions (
                id $autoInc,
                reseller_id INT NOT NULL,
                status VARCHAR(32) DEFAULT 'active',
                activated_at DATETIME NULL,
                expires_at DATETIME NULL,
                price_paid BIGINT DEFAULT 0,
                last_price BIGINT DEFAULT 0,
                note VARCHAR(255) NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (reseller_id)
            )");

            // AI-generated ticket messages (sender_id = 0)
            self::safeAddColumn($pdo, 'ticket_messages', 'is_ai', 'TINYINT(1) DEFAULT 0');

            // Ensure Default Referral Codes for users
            try {
                $usersWithoutRef = $pdo->query("SELECT id, username FROM users WHERE referral_code IS NULL OR referral_code = ''")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($usersWithoutRef as $u) {
                    $code = 'REF' . strtoupper(substr(md5($u['username'] . $u['id']), 0, 6));
                    $pdo->exec("UPDATE users SET referral_code = '{$code}' WHERE id = {$u['id']}");
                }
            } catch (Throwable $e) {}

        } catch (Throwable $e) {
            // Safe failover
        }
    }

    public static function initializeSqliteSchema(?PDO $pdo = null): void {
        if ($pdo === null) {
            $pdo = self::$instance ?: self::getConnection();
        }
        $schema = <<<SQL
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'reseller', -- 'admin' or 'reseller'
    full_name TEXT,
    email TEXT,
    wallet_balance INTEGER NOT NULL DEFAULT 0, -- in Tomans
    discount_percent INTEGER NOT NULL DEFAULT 0,
    allowed_groups TEXT DEFAULT 'all', -- 'all' or comma-separated groups
    api_token TEXT UNIQUE,
    status TEXT NOT NULL DEFAULT 'active', -- 'active', 'suspended'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS server_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    driver TEXT NOT NULL, -- 'marzban', 'pasargad', '3xui', 'mock'
    api_url TEXT NOT NULL,
    api_username TEXT,
    api_password TEXT,
    api_token TEXT,
    server_group TEXT NOT NULL DEFAULT 'default', -- 'default', 'economic', 'iran_access', 'vip'
    sub_domain TEXT,
    inbound_tag TEXT,
    max_clients INTEGER DEFAULT 0, -- 0 = Unlimited
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    traffic_gb REAL NOT NULL,
    duration_days INTEGER NOT NULL,
    base_price INTEGER NOT NULL, -- Tomans
    reseller_price INTEGER NOT NULL, -- Tomans
    server_group TEXT NOT NULL DEFAULT 'default',
    server_id INTEGER NULL DEFAULT NULL,
    category_id INTEGER NULL DEFAULT NULL,
    category TEXT DEFAULT '۱ ماهه',
    show_in_bot INTEGER DEFAULT 1,
    ip_limit INTEGER DEFAULT 0,
    max_devices INTEGER DEFAULT 0,
    start_on_first_use INTEGER DEFAULT 0,
    is_free INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reseller_id INTEGER NOT NULL,
    server_id INTEGER NOT NULL,
    plan_id INTEGER,
    username TEXT UNIQUE NOT NULL,
    password TEXT,
    uuid TEXT UNIQUE NOT NULL,
    sub_token TEXT UNIQUE NOT NULL,
    traffic_limit_bytes INTEGER NOT NULL,
    traffic_used_bytes INTEGER DEFAULT 0,
    expire_at DATETIME,
    status TEXT NOT NULL DEFAULT 'active', -- 'active', 'expired', 'disabled', 'never_connected'
    last_connected_at DATETIME,
    custom_note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(reseller_id) REFERENCES users(id),
    FOREIGN KEY(server_id) REFERENCES server_nodes(id),
    FOREIGN KEY(plan_id) REFERENCES plans(id)
);

CREATE TABLE IF NOT EXISTS reserved_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,
    traffic_gb REAL NOT NULL,
    duration_days INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'queued', -- 'queued', 'applied', 'cancelled'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    applied_at DATETIME,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY(plan_id) REFERENCES plans(id)
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount INTEGER NOT NULL, -- positive for credit, negative for purchase
    balance_after INTEGER NOT NULL,
    type TEXT NOT NULL, -- 'wallet_topup', 'plan_purchase', 'plan_renewal', 'refund'
    description TEXT,
    reference_id TEXT,
    status TEXT NOT NULL DEFAULT 'completed', -- 'completed', 'pending', 'failed'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS branding_metadata (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    brand_name TEXT DEFAULT 'Connectix VPN',
    theme_color TEXT DEFAULT 'violet', -- 'violet', 'blue', 'orange', 'green', 'black'
    logo_url TEXT,
    telegram_support TEXT,
    whatsapp_support TEXT,
    welcome_message TEXT,
    renewal_url TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    target_role TEXT DEFAULT 'all', -- 'all', 'reseller'
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
SQL;
        $pdo->exec($schema);
        self::seedDefaultData($pdo);
    }

    public static function seedDefaultData(PDO $pdo): void {
        // Seed default Admin: admin / admin123
        $adminPass = password_hash('admin123', PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT OR IGNORE INTO users (id, username, password_hash, role, full_name, email, wallet_balance, api_token) VALUES (1, 'admin', ?, 'admin', 'مدیر کل سیستم', 'admin@connectix.local', 0, 'admin_secret_token_123')");
        $stmt->execute([$adminPass]);

        // Seed default Branding
        $pdo->exec("INSERT OR IGNORE INTO branding_metadata (user_id, brand_name, theme_color, telegram_support, whatsapp_support, welcome_message) VALUES (1, 'Connectix Panel', 'violet', '@Connectix_Admin', '+989000000000', 'به پنل مدیریت اختصاصی کانکتیکس خوش آمدید.')");
    }

    /**
     * Restore database tables and records from SQL backup content
     */
    public static function restoreFromSql(string $sqlContent): array {
        $pdo = self::getConnection();
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        
        $sqlLines = explode("\n", $sqlContent);
        $cleanSql = '';
        foreach ($sqlLines as $line) {
            $trimmed = trim($line);
            if (str_starts_with($trimmed, '--') || str_starts_with($trimmed, '#') || str_starts_with($trimmed, '/*')) {
                continue;
            }
            $cleanSql .= $line . "\n";
        }
        
        $statements = array_filter(array_map('trim', explode(';', $cleanSql)));
        if (empty($statements)) {
            return ['success' => false, 'error' => 'هیچ دستور SQL معتبری در فایل بکاپ یافت نشد.'];
        }

        $executed = 0;
        $failed = 0;
        
        if ($driver === 'mysql') {
            try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;"); } catch (Throwable $e) {}
        } else {
            try { $pdo->exec("PRAGMA foreign_keys = OFF;"); } catch (Throwable $e) {}
        }

        foreach ($statements as $stmt) {
            if (empty($stmt)) continue;
            try {
                $pdo->exec($stmt);
                $executed++;
            } catch (Throwable $e) {
                $failed++;
            }
        }

        if ($driver === 'mysql') {
            try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;"); } catch (Throwable $e) {}
        } else {
            try { $pdo->exec("PRAGMA foreign_keys = ON;"); } catch (Throwable $e) {}
        }

        // Re-run schema assurance in case new auxiliary columns are needed
        self::ensureExtendedTablesExist($pdo);

        return [
            'success' => true,
            'executed' => $executed,
            'failed' => $failed,
            'total' => count($statements)
        ];
    }
}
